import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import ThemeToggle from "./components/ThemeToggle";
import LanguageSwitcher from "./components/LanguageSwitcher";
import SetupScreen from "./components/SetupScreen";
import GeneratingOverlay from "./components/GeneratingOverlay";
import QuizScreen from "./components/QuizScreen";
import ResultsScreen from "./components/ResultsScreen";
import { DIFFICULTIES, type DifficultyId, type QuizPayload } from "./lib/types";
import { generateQuiz } from "./lib/generate";
import { T, type Lang } from "./lib/i18n";

type Phase = "setup" | "generating" | "quiz" | "results";

const DIFF_HEX: Record<DifficultyId, string> = {
  facil: "#22c55e",
  medio: "#eab308",
  dificil: "#ef4444",
};

export default function App() {
  const [dark, setDark] = useState<boolean>(() => {
    const saved = localStorage.getItem("quizmind-theme");
    return saved ? saved === "dark" : true;
  });
  const [lang, setLang] = useState<Lang>(() => {
    const saved = localStorage.getItem("quizmind-lang");
    return saved === "en" || saved === "pt" ? saved : "es";
  });
  const [phase, setPhase] = useState<Phase>("setup");
  const [topic, setTopic] = useState("");
  const [count, setCount] = useState(10);
  const [difficulty, setDifficulty] = useState<DifficultyId>("facil");

  const [quiz, setQuiz] = useState<QuizPayload | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [seconds, setSeconds] = useState(0);

  const generationRef = useRef(0);
  const t = T[lang];
  const diffHex = DIFF_HEX[difficulty];
  const diffLabel = t.diff[difficulty].label;

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("quizmind-theme", dark ? "dark" : "light");
    document
      .querySelector('meta[name="theme-color"]')
      ?.setAttribute("content", dark ? "#070709" : "#f6f6f8");
  }, [dark]);

  useEffect(() => {
    document.documentElement.lang = lang === "en" ? "en" : lang === "pt" ? "pt" : "es";
    localStorage.setItem("quizmind-lang", lang);
  }, [lang]);

  const startGeneration = useCallback(async () => {
    if (topic.trim().length < 2) return;
    const id = ++generationRef.current;
    setPhase("generating");
    try {
      const result = await generateQuiz(
        topic.trim(),
        count,
        { id: difficulty, idx: DIFFICULTIES.find((d) => d.id === difficulty)!.idx },
        lang
      );
      if (generationRef.current !== id) return;
      if (result.questions.length === 0) throw new Error("sin preguntas");
      setQuiz(result);
      setPhase("quiz");
      window.scrollTo({ top: 0 });
    } catch (err) {
      console.error(err);
      if (generationRef.current === id) setPhase("setup");
    }
  }, [topic, count, difficulty, lang]);

  const cancelGeneration = useCallback(() => {
    generationRef.current++;
    setPhase("setup");
  }, []);

  const finishQuiz = useCallback((ans: number[], secs: number) => {
    setAnswers(ans);
    setSeconds(secs);
    setPhase("results");
    window.scrollTo({ top: 0 });
  }, []);

  return (
    <div
      className="flex min-h-screen flex-col transition-colors duration-500"
      style={{ "--accent": diffHex } as CSSProperties}
    >
      {/* -------- fondo ambiental -------- */}
      <div aria-hidden className="pointer-events-none fixed inset-0 overflow-hidden">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "linear-gradient(var(--line) 1px, transparent 1px), linear-gradient(90deg, var(--line) 1px, transparent 1px)",
            backgroundSize: "48px 48px",
            maskImage: "radial-gradient(ellipse 90% 65% at 50% 0%, black 25%, transparent 78%)",
            WebkitMaskImage: "radial-gradient(ellipse 90% 65% at 50% 0%, black 25%, transparent 78%)",
          }}
        />
        <div
          className="absolute -top-40 left-1/2 h-[480px] w-[720px] -translate-x-1/2 rounded-full blur-3xl transition-colors duration-700"
          style={{ background: `radial-gradient(closest-side, ${diffHex}1c, transparent)` }}
        />
        <div
          className="absolute -bottom-56 -left-40 h-[420px] w-[420px] rounded-full blur-3xl transition-colors duration-700"
          style={{ background: `radial-gradient(closest-side, ${diffHex}12, transparent)` }}
        />
      </div>

      {/* -------- cabecera -------- */}
      <header className="relative z-40 mx-auto flex w-full max-w-6xl items-center justify-between px-5 py-5 sm:px-8">
        <button
          onClick={() => phase !== "generating" && setPhase("setup")}
          className="group flex cursor-pointer items-center gap-2.5"
          aria-label="QuizMind"
        >
          <span
            className="flex h-9 w-9 items-center justify-center rounded-xl transition-all duration-500 group-hover:rotate-12"
            style={{ backgroundColor: diffHex, boxShadow: `0 8px 24px -8px ${diffHex}` }}
          >
            <Sparkles size={17} color={difficulty === "medio" ? "#171205" : "#fff"} strokeWidth={2.4} />
          </span>
          <span className="font-display text-lg font-bold tracking-tight">
            Quiz<span style={{ color: diffHex, transition: "color .5s" }}>Mind</span>
          </span>
        </button>
        <div className="flex items-center gap-2.5">
          <LanguageSwitcher lang={lang} onChange={setLang} label={t.langLabel} />
          <ThemeToggle dark={dark} onToggle={() => setDark((v) => !v)} label={dark ? t.themeToggleLight : t.themeToggleDark} />
        </div>
      </header>

      {/* -------- contenido -------- */}
      <main className="relative z-10 flex flex-1 flex-col">
        <AnimatePresence mode="wait">
          {phase === "setup" && (
            <motion.div
              key="setup"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0, y: -14 }}
              transition={{ duration: 0.35 }}
            >
              <SetupScreen
                topic={topic}
                setTopic={setTopic}
                count={count}
                setCount={setCount}
                difficulty={difficulty}
                setDifficulty={setDifficulty}
                difficulties={DIFFICULTIES}
                onGenerate={startGeneration}
                t={t}
              />
            </motion.div>
          )}

          {phase === "quiz" && quiz && (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
              className="flex flex-1 flex-col"
            >
              <QuizScreen
                topic={topic}
                quiz={quiz}
                diffHex={diffHex}
                diffLabel={diffLabel}
                diffId={difficulty}
                onFinish={finishQuiz}
                onQuit={() => setPhase("setup")}
                t={t}
              />
            </motion.div>
          )}

          {phase === "results" && quiz && (
            <motion.div
              key="results"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
            >
              <ResultsScreen
                topic={topic}
                quiz={quiz}
                answers={answers}
                seconds={seconds}
                diffHex={diffHex}
                diffLabel={diffLabel}
                diffId={difficulty}
                onRetry={startGeneration}
                onNewTopic={() => setPhase("setup")}
                t={t}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* -------- pie -------- */}
      <footer className="relative z-10 mx-auto w-full max-w-6xl px-5 pb-6 pt-2 sm:px-8">
        <p className="text-center text-[11px] text-[var(--muted)] opacity-70">{t.footer}</p>
      </footer>

      {/* -------- overlay de generación -------- */}
      <AnimatePresence>
        {phase === "generating" && (
          <GeneratingOverlay
            topic={topic}
            count={count}
            diffHex={diffHex}
            diffLabel={diffLabel}
            t={t}
            onCancel={cancelGeneration}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
