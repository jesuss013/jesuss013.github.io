import { useEffect, useState, type CSSProperties } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Sparkles, X } from "lucide-react";
import type { Strings } from "../lib/i18n";

interface Props {
  topic: string;
  count: number;
  diffHex: string;
  diffLabel: string;
  t: Strings;
  onCancel: () => void;
}

export default function GeneratingOverlay({ topic, count, diffHex, diffLabel, t, onCancel }: Props) {
  const [msg, setMsg] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setMsg((m) => (m + 1) % t.generating.length), 1800);
    return () => clearInterval(id);
  }, [t.generating.length]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-[color-mix(in_srgb,var(--bg)_82%,transparent)] px-6 backdrop-blur-xl"
      style={{ "--accent": diffHex } as CSSProperties}
    >
      <div className="flex w-full max-w-md flex-col items-center text-center">
        {/* anillos animados */}
        <div className="relative mb-10 h-32 w-32">
          <div
            className="absolute inset-0 rounded-full border-2 border-dashed opacity-50"
            style={{
              borderColor: diffHex,
              animation: "qm-spin 9s linear infinite",
            }}
          />
          <div
            className="absolute inset-4 rounded-full border border-[var(--line)]"
            style={{ animation: "qm-spin-rev 12s linear infinite", borderStyle: "dotted" }}
          />
          <div
            className="absolute inset-9 rounded-full"
            style={{
              background: `radial-gradient(circle at 50% 35%, color-mix(in srgb, ${diffHex} 90%, white) 0%, ${diffHex} 70%)`,
              boxShadow: `0 0 60px ${diffHex}88`,
              animation: "qm-pulse 2.2s ease-in-out infinite",
            }}
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <Sparkles size={26} color="#fff" strokeWidth={2.2} />
          </div>
        </div>

        <p className="mb-1 text-[11px] font-bold uppercase tracking-[0.25em] text-[var(--muted)]">
          {t.generatingTopic}
        </p>
        <div className="mb-3 h-7 overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.p
              key={msg}
              initial={{ y: 22, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -22, opacity: 0 }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              className="font-display text-lg font-semibold"
            >
              {t.generating[msg]}
            </motion.p>
          </AnimatePresence>
        </div>

        <p className="mb-6 max-w-xs text-sm leading-relaxed text-[var(--muted)]">
          «{topic}» · {count} ·{" "}
          <span className="font-semibold" style={{ color: diffHex }}>
            {diffLabel.toLowerCase()}
          </span>
        </p>

        {/* barra shimmer */}
        <div className="mb-8 h-1.5 w-56 overflow-hidden rounded-full bg-[var(--line)]">
          <div
            className="h-full w-1/3 rounded-full"
            style={{
              background: diffHex,
              animation: "qm-shimmer 1.4s ease-in-out infinite",
            }}
          />
        </div>

        <button
          onClick={onCancel}
          className="accent-ring flex cursor-pointer items-center gap-2 rounded-full border border-[var(--line)] px-5 py-2.5 text-xs font-semibold text-[var(--muted)] transition-all duration-300 hover:border-[color-mix(in_srgb,var(--fg)_35%,transparent)] hover:text-[var(--fg)]"
        >
          <X size={13} />
          {t.cancel}
        </button>
      </div>
    </motion.div>
  );
}
