import { AnimatePresence, motion } from "framer-motion";
import { Moon, Sun } from "lucide-react";

interface Props {
  dark: boolean;
  onToggle: () => void;
  label: string;
}

export default function ThemeToggle({ dark, onToggle, label }: Props) {
  return (
    <button
      onClick={onToggle}
      title={label}
      aria-label={label}
      className="accent-ring relative flex h-11 w-11 cursor-pointer items-center justify-center overflow-hidden rounded-full border border-[var(--line)] bg-[var(--card)] transition-all duration-300 hover:scale-105 hover:border-[color-mix(in_srgb,var(--fg)_30%,transparent)] active:scale-95"
    >
      <AnimatePresence mode="wait" initial={false}>
        <motion.span
          key={dark ? "moon" : "sun"}
          initial={{ y: 14, opacity: 0, rotate: -60 }}
          animate={{ y: 0, opacity: 1, rotate: 0 }}
          exit={{ y: -14, opacity: 0, rotate: 60 }}
          transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
          className="text-[var(--fg)]"
        >
          {dark ? <Sun size={18} strokeWidth={2.2} /> : <Moon size={18} strokeWidth={2.2} />}
        </motion.span>
      </AnimatePresence>
    </button>
  );
}
