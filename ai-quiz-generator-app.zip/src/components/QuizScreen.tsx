import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, Award, Check, CheckCircle2, CircleDot, Lightbulb, LogOut, X, XCircle } from "lucide-react";
import type { QuizPayload } from "../lib/types";
import type { Strings } from "../lib/i18n";

const LETTERS = ["A", "B", "C", "D"];
const GREEN = "#22c55e";
const RED = "#ef4444";

interface Props {
  topic: string;
  quiz: QuizPayload;
  diffHex: string;
  diffLabel: string;
  diffId: string;
  onFinish: (answers: number[], seconds: number) => void;
  onQuit: () => void;
  t: Strings;
}

export default function QuizScreen({ topic, quiz, diffHex, diffLabel, diffId, onFinish, onQuit, t }: Props) {
  const questions = quiz.questions;
  const total = questions.length;

  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<number[]>(() => new Array(total).fill(-1));
  const [selected, setSelected] = useState<number | null>(null);
  const [confirmFinish, setConfirmFinish] = useState(false);
  const startRef = useRef<number>(Date.now());

  const q = questions[index];
  const revealed = selected !== null;
  const isLast = index === total - 1;
  const correctCount = useMemo(
    () => answers.filter((a, i) => a >= 0 && a === questions[i].correcta).length,
    [answers, questions]
  );
  const answeredCount = answers.filter((a) => a >= 0).length;

  const choose = (i: number) => {
    if (revealed) return;
    setSelected(i);
    setAnswers((prev) => {
      const next = [...prev];
      next[index] = i;
      return next;
    });
  };

  const finishNow = () => {
    onFinish(answers, Math.round((Date.now() - startRef.current) / 1000));
  };

  const next = () => {
    if (!revealed) return;
    if (isLast) {
      finishNow();
    } else {
      setIndex((v) => v + 1);
      setSelected(null);
    }
  };

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (confirmFinish) return;
      if (e.key === "Enter") {
        e.preventDefault();
        next();
        return;
      }
      const map: Record<string, number> =
        q.tipo === "vf"
          ? { "1": 0, "2": 1, a: 0, b: 1, v: 0, t: 0, f: 1 }
          : { "1": 0, "2": 1, "3": 2, "4": 3, a: 0, b: 1, c: 2, d: 3 };
      const k = map[e.key.toLowerCase()];
      if (k !== undefined) choose(k);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [revealed, index, isLast, answers, confirmFinish]);

  const progressPct = ((index + (revealed ? 1 : 0)) / total) * 100;

  return (
    <div
      style={{ "--accent": diffHex } as CSSProperties}
      className="relative mx-auto flex min-h-full w-full max-w-3xl flex-col px-5 pb-16 pt-8 sm:px-8"
    >
      {/* -------- cabecera -------- */}
      <div className="mb-8">
        <div className="mb-4 flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2">
            <span
              className="inline-flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-wider"
              style={{
                backgroundColor: `color-mix(in srgb, ${diffHex} 16%, transparent)`,
                color: diffHex,
              }}
            >
              {diffLabel}
            </span>
            <span className="truncate text-sm font-medium text-[var(--muted)]">{topic}</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 text-sm font-semibold tabular-nums">
              <Award size={15} style={{ color: GREEN }} />
              {correctCount}
            </span>
            <button
              onClick={onQuit}
              title={t.quit}
              aria-label={t.quit}
              className="accent-ring cursor-pointer rounded-full border border-[var(--line)] p-2 text-[var(--muted)] transition-all duration-300 hover:text-[var(--fg)]"
            >
              <LogOut size={15} />
            </button>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span className="font-display text-sm font-bold tabular-nums">
            {String(index + 1).padStart(2, "0")}
            <span className="text-[var(--muted)]"> / {String(total).padStart(2, "0")}</span>
          </span>
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-[var(--line)]">
            <motion.div
              className="h-full rounded-full"
              style={{ backgroundColor: diffHex }}
              initial={false}
              animate={{ width: `${progressPct}%` }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            />
          </div>
        </div>
      </div>

      {/* -------- pregunta -------- */}
      <AnimatePresence mode="wait">
        <motion.div
          key={index}
          initial={{ opacity: 0, x: 46 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -46 }}
          transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
          className="flex flex-1 flex-col"
        >
          <div className="relative mb-7">
            <span
              aria-hidden
              className="pointer-events-none absolute -top-9 left-0 select-none font-display text-[7rem] font-bold leading-none opacity-[0.05]"
            >
              {String(index + 1).padStart(2, "0")}
            </span>
            <span
              className="relative mb-3 inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[10px] font-bold uppercase tracking-widest"
              style={{
                borderColor: `color-mix(in srgb, ${diffHex} 45%, transparent)`,
                color: diffHex,
                backgroundColor: `color-mix(in srgb, ${diffHex} 8%, transparent)`,
              }}
            >
              <CircleDot size={11} />
              {q.tipo === "vf" ? t.typeVf : t.typeMc}
            </span>
            <h2 className="relative font-display text-2xl font-bold leading-snug tracking-tight sm:text-3xl">
              {q.pregunta}
            </h2>
          </div>

          {/* -------- opciones -------- */}
          {q.tipo === "vf" ? (
            <div className="grid grid-cols-2 gap-3">
              {q.opciones.map((opt, i) => {
                const isCorrect = i === q.correcta;
                const isSelected = i === selected;
                const tone = i === 0 ? GREEN : RED;
                let border = `color-mix(in srgb, ${tone} 35%, var(--line))`;
                let bg = "var(--card)";
                if (revealed && isCorrect) {
                  border = GREEN;
                  bg = `color-mix(in srgb, ${GREEN} 14%, var(--card))`;
                } else if (revealed && isSelected) {
                  border = RED;
                  bg = `color-mix(in srgb, ${RED} 14%, var(--card))`;
                }
                return (
                  <motion.button
                    key={i}
                    onClick={() => choose(i)}
                    disabled={revealed}
                    whileTap={!revealed ? { scale: 0.96 } : undefined}
                    whileHover={!revealed ? { y: -3 } : undefined}
                    className="group accent-ring flex cursor-pointer flex-col items-center gap-3 rounded-2xl border p-7 transition-colors duration-300 disabled:cursor-default sm:p-9"
                    style={{
                      borderColor: border,
                      backgroundColor: bg,
                      boxShadow:
                        revealed && (isCorrect || isSelected)
                          ? `0 14px 34px -14px ${isCorrect ? GREEN : RED}`
                          : "none",
                      opacity: revealed && !isCorrect && !isSelected ? 0.5 : 1,
                    }}
                  >
                    <span
                      className="flex h-12 w-12 items-center justify-center rounded-full transition-transform duration-300 group-hover:scale-110"
                      style={{
                        backgroundColor:
                          revealed && (isCorrect || isSelected)
                            ? isCorrect
                              ? GREEN
                              : RED
                            : `color-mix(in srgb, ${tone} 16%, transparent)`,
                        color:
                          revealed && (isCorrect || isSelected) ? "#fff" : tone,
                      }}
                    >
                      {i === 0 ? (
                        <Check size={22} strokeWidth={3} />
                      ) : (
                        <X size={22} strokeWidth={3} />
                      )}
                    </span>
                    <span className="font-display text-lg font-bold tracking-tight sm:text-xl">
                      {opt}
                    </span>
                  </motion.button>
                );
              })}
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {q.opciones.map((opt, i) => {
                const isCorrect = i === q.correcta;
                const isSelected = i === selected;
                let border = "var(--line)";
                let bg = "var(--card)";
                let fg = "var(--fg)";
                let badgeBg = "color-mix(in srgb, var(--fg) 6%, transparent)";
                let badgeFg = "var(--muted)";

                if (revealed && isCorrect) {
                  border = GREEN;
                  bg = `color-mix(in srgb, ${GREEN} 12%, var(--card))`;
                  badgeBg = GREEN;
                  badgeFg = "#fff";
                } else if (revealed && isSelected) {
                  border = RED;
                  bg = `color-mix(in srgb, ${RED} 12%, var(--card))`;
                  badgeBg = RED;
                  badgeFg = "#fff";
                } else if (revealed) {
                  fg = "color-mix(in srgb, var(--fg) 45%, transparent)";
                }

                return (
                  <motion.button
                    key={i}
                    onClick={() => choose(i)}
                    disabled={revealed}
                    whileTap={!revealed ? { scale: 0.985 } : undefined}
                    initial={false}
                    className="group accent-ring flex w-full cursor-pointer items-center gap-4 rounded-2xl border p-4 text-left transition-all duration-300 hover:-translate-y-0.5 disabled:cursor-default disabled:hover:translate-y-0 sm:p-[18px]"
                    style={{
                      borderColor: border,
                      backgroundColor: bg,
                      color: fg,
                      boxShadow:
                        revealed && (isCorrect || isSelected)
                          ? `0 12px 30px -14px ${isCorrect ? GREEN : RED}`
                          : "none",
                      opacity: revealed && !isCorrect && !isSelected ? 0.55 : 1,
                    }}
                  >
                    <span
                      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl font-display text-sm font-bold transition-colors duration-300"
                      style={{ backgroundColor: badgeBg, color: badgeFg }}
                    >
                      {revealed && isCorrect ? (
                        <Check size={17} strokeWidth={3} />
                      ) : revealed && isSelected ? (
                        <X size={17} strokeWidth={3} />
                      ) : (
                        LETTERS[i]
                      )}
                    </span>
                    <span className="text-[15px] font-medium leading-snug sm:text-base">{opt}</span>
                  </motion.button>
                );
              })}
            </div>
          )}

          {/* -------- explicación -------- */}
          <AnimatePresence>
            {revealed && (
              <motion.div
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 8 }}
                transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                className="mt-6 flex items-start gap-3 rounded-2xl border p-4 sm:p-5"
                style={{
                  borderColor: `color-mix(in srgb, ${selected === q.correcta ? GREEN : RED} 40%, transparent)`,
                  backgroundColor: `color-mix(in srgb, ${selected === q.correcta ? GREEN : RED} 8%, transparent)`,
                }}
              >
                <span
                  className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl"
                  style={{
                    backgroundColor: selected === q.correcta ? GREEN : RED,
                    color: "#fff",
                  }}
                >
                  {selected === q.correcta ? <CheckCircle2 size={16} /> : <XCircle size={16} />}
                </span>
                <div>
                  <p className="mb-0.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[var(--muted)]">
                    <Lightbulb size={12} />
                    {selected === q.correcta ? t.correct : t.incorrect}
                  </p>
                  <p className="text-sm leading-relaxed text-[color-mix(in_srgb,var(--fg)_88%,transparent)]">
                    {q.explicacion}
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </AnimatePresence>

      {/* -------- pie / siguiente -------- */}
      <div className="mt-8">
        <div className="flex flex-col gap-3 sm:flex-row">
          <motion.button
            onClick={next}
            disabled={!revealed}
            whileTap={revealed ? { scale: 0.98 } : undefined}
            className="accent-ring flex flex-1 cursor-pointer items-center justify-center gap-2.5 rounded-2xl px-8 py-4.5 font-display text-base font-bold tracking-tight transition-all duration-300 disabled:cursor-not-allowed sm:py-5"
            style={{
              backgroundColor: revealed ? diffHex : "color-mix(in srgb, var(--fg) 8%, transparent)",
              color: !revealed
                ? "color-mix(in srgb, var(--fg) 35%, transparent)"
                : diffId === "medio"
                  ? "#171205"
                  : "#fff",
              boxShadow: revealed ? `0 16px 40px -16px ${diffHex}` : "none",
            }}
          >
            {isLast ? t.seeResults : t.next}
            <ArrowRight size={18} strokeWidth={2.5} />
          </motion.button>
          {answeredCount < total && (
            <button
              onClick={() => setConfirmFinish(true)}
              className="accent-ring cursor-pointer rounded-2xl border border-[var(--line)] px-6 py-4 font-display text-sm font-semibold text-[var(--muted)] transition-all duration-300 hover:text-[var(--fg)] sm:py-5"
            >
              {t.seeResults}
            </button>
          )}
        </div>
        <p className="mt-3 text-center text-[11px] text-[var(--muted)] opacity-70">
          {q.tipo === "vf" ? t.keyHintVf : t.keyHintMc}
        </p>
      </div>

      {/* -------- diálogo terminar ahora -------- */}
      <AnimatePresence>
        {confirmFinish && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-[color-mix(in_srgb,var(--bg)_72%,transparent)] px-6 backdrop-blur-sm"
            onClick={() => setConfirmFinish(false)}
          >
            <motion.div
              initial={{ scale: 0.92, y: 16, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.92, y: 16, opacity: 0 }}
              transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-sm rounded-3xl border border-[var(--line)] bg-[var(--card)] p-7 shadow-2xl"
            >
              <h3 className="mb-2 font-display text-xl font-bold tracking-tight">
                {t.unfinishedTitle}
              </h3>
              <p className="mb-6 text-sm leading-relaxed text-[var(--muted)]">
                {t.unfinishedDesc}
              </p>
              <div className="flex flex-col gap-2.5">
                <button
                  onClick={finishNow}
                  className="accent-ring w-full cursor-pointer rounded-xl px-5 py-3.5 font-display text-sm font-bold text-white"
                  style={{ backgroundColor: diffHex, color: diffId === "medio" ? "#171205" : "#fff" }}
                >
                  {t.unfinishedFinish}
                </button>
                <button
                  onClick={() => setConfirmFinish(false)}
                  className="accent-ring w-full cursor-pointer rounded-xl border border-[var(--line)] px-5 py-3.5 font-display text-sm font-semibold text-[var(--fg)] transition-colors duration-200 hover:bg-[color-mix(in_srgb,var(--fg)_5%,transparent)]"
                >
                  {t.unfinishedStay}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
