import { type CSSProperties, useMemo } from "react";
import { motion, type Variants } from "framer-motion";
import { ArrowRight, Hash, SlidersHorizontal, Sparkles } from "lucide-react";
import type { DifficultyMeta, DifficultyId } from "../lib/types";
import type { Strings } from "../lib/i18n";

interface Props {
  topic: string;
  setTopic: (v: string) => void;
  count: number;
  setCount: (v: number) => void;
  difficulty: DifficultyId;
  setDifficulty: (v: DifficultyId) => void;
  difficulties: DifficultyMeta[];
  onGenerate: () => void;
  t: Strings;
}

const container: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.07, delayChildren: 0.05 } },
};
const item: Variants = {
  hidden: { opacity: 0, y: 22 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } },
};

export default function SetupScreen({
  topic,
  setTopic,
  count,
  setCount,
  difficulty,
  setDifficulty,
  difficulties,
  onGenerate,
  t,
}: Props) {
  const diff = difficulties.find((d) => d.id === difficulty)!;
  const ready = topic.trim().length >= 2;
  const pct = ((count - 1) / 19) * 100;

  const accentStyle = useMemo(
    () => ({ "--accent": diff.hex }) as CSSProperties,
    [diff.hex]
  );

  const submit = () => {
    if (ready) onGenerate();
  };

  return (
    <div style={accentStyle} className="mx-auto w-full max-w-4xl px-5 pb-24 pt-10 sm:px-8 md:pt-16">
      <motion.div variants={container} initial="hidden" animate="show">
        {/* -------- encabezado -------- */}
        <motion.div variants={item} className="mb-10 text-center md:mb-14">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[var(--line)] bg-[var(--card)] px-4 py-1.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-[var(--muted)] transition-colors duration-500">
            <Sparkles size={13} style={{ color: diff.hex, transition: "color .4s" }} />
            {t.badge}
          </div>
          <h1 className="font-display text-4xl font-bold leading-[1.08] tracking-tight sm:text-5xl md:text-6xl">
            {t.heroA}{" "}
            <span className="relative inline-block" style={{ color: diff.hex, transition: "color .5s" }}>
              {t.heroB}
              <svg
                className="absolute -bottom-2 left-0 w-full"
                viewBox="0 0 220 12"
                fill="none"
                preserveAspectRatio="none"
                aria-hidden
              >
                <path
                  d="M3 9C60 4 160 3 217 8"
                  stroke={diff.hex}
                  strokeWidth="4"
                  strokeLinecap="round"
                  opacity="0.55"
                  style={{ transition: "stroke .5s" }}
                />
              </svg>
            </span>
            <br className="hidden sm:block" /> {t.heroC}
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-sm leading-relaxed text-[var(--muted)] sm:text-base">
            {t.sub}
          </p>
        </motion.div>

        {/* -------- tarjeta principal -------- */}
        <motion.div
          variants={item}
          className="glass-panel overflow-hidden rounded-3xl shadow-[0_24px_80px_-24px_rgba(0,0,0,0.25)]"
        >
          {/* Tema */}
          <div className="border-b border-[var(--line)] p-6 sm:p-8">
            <label
              htmlFor="topic"
              className="mb-3 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.22em] text-[var(--muted)]"
            >
              <Hash size={13} /> {t.topicLabel}
            </label>
            <input
              id="topic"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submit()}
              placeholder={t.topicPlaceholder}
              autoFocus
              maxLength={120}
              className="accent-ring w-full rounded-xl border border-transparent bg-transparent font-display text-2xl font-semibold tracking-tight text-[var(--fg)] placeholder:text-[color-mix(in_srgb,var(--muted)_55%,transparent)] focus:border-[var(--line)] focus:bg-[color-mix(in_srgb,var(--fg)_3%,transparent)] sm:text-3xl"
            />
            <div className="mt-4 flex flex-wrap gap-2">
              {t.suggestions.map((s) => (
                <button
                  key={s}
                  onClick={() => setTopic(s)}
                  className={`accent-ring cursor-pointer rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all duration-300 hover:-translate-y-0.5 ${
                    topic === s
                      ? "border-transparent text-white"
                      : "border-[var(--line)] bg-[color-mix(in_srgb,var(--fg)_4%,transparent)] text-[var(--muted)] hover:text-[var(--fg)]"
                  }`}
                  style={topic === s ? { backgroundColor: diff.hex } : undefined}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Controles */}
          <div className="grid gap-0 md:grid-cols-2">
            {/* Slider número de preguntas */}
            <div className="border-b border-[var(--line)] p-6 sm:p-8 md:border-b-0 md:border-r">
              <div className="mb-5 flex items-center justify-between">
                <span className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.22em] text-[var(--muted)]">
                  <SlidersHorizontal size={13} /> {t.countLabel}
                </span>
                <motion.span
                  key={count}
                  initial={{ scale: 0.8, opacity: 0.4 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: "spring", stiffness: 400, damping: 22 }}
                  className="font-display text-4xl font-bold tabular-nums leading-none"
                  style={{ color: diff.hex, transition: "color .4s" }}
                >
                  {count}
                </motion.span>
              </div>
              <input
                type="range"
                min={1}
                max={20}
                step={1}
                value={count}
                onChange={(e) => setCount(Number(e.target.value))}
                aria-label={t.countLabel}
                className="qm-range accent-ring"
                style={
                  {
                    "--track-bg": `linear-gradient(90deg, ${diff.hex} 0%, ${diff.hex} ${pct}%, var(--line) ${pct}%, var(--line) 100%)`,
                  } as CSSProperties
                }
              />
              <div className="mt-3 flex justify-between text-[11px] font-medium text-[var(--muted)]">
                <span>1</span>
                <span>10</span>
                <span>20</span>
              </div>
            </div>

            {/* Dificultad */}
            <div className="p-6 sm:p-8">
              <span className="mb-5 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.22em] text-[var(--muted)]">
                <Sparkles size={13} /> {t.difficultyLabel}
              </span>
              <div className="flex gap-2.5">
                {difficulties.map((d) => {
                  const active = d.id === difficulty;
                  return (
                    <motion.button
                      key={d.id}
                      onClick={() => setDifficulty(d.id)}
                      whileTap={{ scale: 0.94 }}
                      className="accent-ring flex flex-1 cursor-pointer flex-col items-center gap-2 rounded-2xl border px-2 py-4 transition-colors duration-300"
                      style={{
                        backgroundColor: active
                          ? d.hex
                          : "color-mix(in srgb, var(--fg) 4%, transparent)",
                        borderColor: active ? d.hex : "var(--line)",
                        color: active ? (d.id === "medio" ? "#171205" : "#fff") : "var(--fg)",
                        boxShadow: active ? `0 10px 30px -8px ${d.hex}99` : "none",
                      }}
                    >
                      <span
                        className="h-2 w-2 rounded-full transition-all duration-300"
                        style={{
                          backgroundColor: active
                            ? d.id === "medio"
                              ? "#171205"
                              : "#fff"
                            : d.hex,
                        }}
                      />
                      <span className="text-sm font-semibold leading-none">{t.diff[d.id].label}</span>
                    </motion.button>
                  );
                })}
              </div>
              <p className="mt-4 min-h-[2.5rem] text-xs leading-relaxed text-[var(--muted)]">
                {t.diff[difficulty].desc}
              </p>
            </div>
          </div>

          {/* CTA */}
          <div className="border-t border-[var(--line)] p-6 sm:p-8">
            <motion.button
              onClick={submit}
              disabled={!ready}
              whileTap={ready ? { scale: 0.98 } : undefined}
              whileHover={ready ? { y: -2 } : undefined}
              className="group accent-ring relative flex w-full cursor-pointer items-center justify-center gap-3 overflow-hidden rounded-2xl px-8 py-5 font-display text-lg font-bold tracking-tight transition-all duration-300 disabled:cursor-not-allowed disabled:opacity-40"
              style={{
                backgroundColor: diff.hex,
                color: difficulty === "medio" ? "#171205" : "#fff",
                boxShadow: ready ? `0 18px 45px -14px ${diff.hex}` : "none",
              }}
            >
              <span className="pointer-events-none absolute inset-y-0 w-1/3 -translate-x-[220%] bg-white/25 blur-md transition-transform duration-700 ease-out group-hover:translate-x-[420%]" />
              <Sparkles size={20} strokeWidth={2.4} />
              {t.generate(count, t.diff[difficulty].label)}
              <ArrowRight
                size={20}
                strokeWidth={2.4}
                className="transition-transform duration-300 group-hover:translate-x-1.5"
              />
            </motion.button>
            <p className="mt-3.5 text-center text-xs text-[var(--muted)]">
              {t.genNote(count, t.diff[difficulty].label)}
            </p>
          </div>
        </motion.div>

        {/* -------- mini features -------- */}
        <motion.div
          variants={item}
          className="mt-8 grid grid-cols-1 gap-3 text-center sm:grid-cols-3"
        >
          {t.features.map(([ft, fs]) => (
            <div
              key={ft}
              className="rounded-2xl border border-[var(--line)] bg-[color-mix(in_srgb,var(--card)_60%,transparent)] px-4 py-4 transition-colors duration-500"
            >
              <p className="font-display text-sm font-semibold">{ft}</p>
              <p className="mt-0.5 text-xs text-[var(--muted)]">{fs}</p>
            </div>
          ))}
        </motion.div>
      </motion.div>
    </div>
  );
}
