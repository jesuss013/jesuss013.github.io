import { useEffect, useState, type CSSProperties } from "react";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  CheckCircle2,
  Clock,
  RefreshCcw,
  Sparkles,
  Target,
  Trophy,
  XCircle,
} from "lucide-react";
import type { QuizPayload } from "../lib/types";
import type { Strings } from "../lib/i18n";

const GREEN = "#22c55e";
const YELLOW = "#eab308";
const RED = "#ef4444";

interface Props {
  topic: string;
  quiz: QuizPayload;
  answers: number[];
  seconds: number;
  diffHex: string;
  diffLabel: string;
  diffId: string;
  onRetry: () => void;
  onNewTopic: () => void;
  t: Strings;
}

export default function ResultsScreen({
  topic,
  quiz,
  answers,
  seconds,
  diffHex,
  diffLabel,
  diffId,
  onRetry,
  onNewTopic,
  t,
}: Props) {
  const total = quiz.questions.length;
  const correct = answers.filter((a, i) => a === quiz.questions[i].correcta).length;
  const pct = total > 0 ? Math.round((correct / total) * 100) : 0;
  const scoreColor = pct >= 70 ? GREEN : pct >= 40 ? YELLOW : RED;

  const [displayPct, setDisplayPct] = useState(0);
  useEffect(() => {
    const start = performance.now();
    const dur = 1200;
    let raf = 0;
    const tick = (time: number) => {
      const p = Math.min(1, (time - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplayPct(Math.round(eased * pct));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [pct]);

  const R = 84;
  const CIRC = 2 * Math.PI * R;

  const message = pct >= 90 ? t.msg90 : pct >= 70 ? t.msg70 : pct >= 40 ? t.msg40 : t.msg0;

  const fmtTime = (s: number) => {
    const m = Math.floor(s / 60);
    const r = s % 60;
    return m > 0 ? `${m}m ${String(r).padStart(2, "0")}s` : `${r}s`;
  };

  const stats = [
    { icon: CheckCircle2, label: t.hits, value: `${correct}/${total}`, color: GREEN },
    { icon: XCircle, label: t.misses, value: `${total - correct}`, color: RED },
    { icon: Clock, label: t.time, value: fmtTime(seconds), color: "var(--muted)" },
    { icon: Target, label: t.level, value: diffLabel, color: diffHex },
  ];

  return (
    <div
      style={{ "--accent": diffHex } as CSSProperties}
      className="mx-auto w-full max-w-3xl px-5 pb-24 pt-10 sm:px-8"
    >
      {/* -------- puntuación -------- */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="mb-10 flex flex-col items-center text-center"
      >
        <span className="mb-5 inline-flex items-center gap-2 rounded-full border border-[var(--line)] bg-[var(--card)] px-4 py-1.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-[var(--muted)]">
          <Trophy size={13} style={{ color: scoreColor }} />
          {t.resultsTitle(topic)}
        </span>

        <div className="relative mb-5 h-52 w-52">
          <svg viewBox="0 0 200 200" className="h-full w-full -rotate-90">
            <circle cx="100" cy="100" r={R} fill="none" stroke="var(--line)" strokeWidth="12" />
            <motion.circle
              cx="100"
              cy="100"
              r={R}
              fill="none"
              stroke={scoreColor}
              strokeWidth="12"
              strokeLinecap="round"
              strokeDasharray={CIRC}
              initial={{ strokeDashoffset: CIRC }}
              animate={{ strokeDashoffset: CIRC - (CIRC * pct) / 100 }}
              transition={{ duration: 1.3, ease: [0.22, 1, 0.36, 1] }}
              style={{ filter: `drop-shadow(0 0 14px ${scoreColor}66)` }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span
              className="font-display text-6xl font-bold tabular-nums leading-none tracking-tight"
              style={{ color: scoreColor }}
            >
              {displayPct}
              <span className="text-3xl">%</span>
            </span>
            <span className="mt-1 text-xs font-medium uppercase tracking-widest text-[var(--muted)]">
              {t.accuracy}
            </span>
          </div>
        </div>

        <h2 className="font-display text-2xl font-bold tracking-tight sm:text-3xl">{message}</h2>
        {quiz.source === "local" && (
          <p className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-[var(--line)] px-3 py-1 text-[11px] font-medium text-[var(--muted)]">
            <Sparkles size={11} />
            {t.localNote(quiz.bankTitle ?? "")}
          </p>
        )}

        <div className="mt-7 grid w-full max-w-lg grid-cols-2 gap-3 sm:grid-cols-4">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + i * 0.08, duration: 0.5 }}
              className="rounded-2xl border border-[var(--line)] bg-[var(--card)] p-3.5"
            >
              <s.icon size={16} style={{ color: s.color }} className="mb-1.5" />
              <p className="font-display text-lg font-bold leading-none">{s.value}</p>
              <p className="mt-1 text-[10px] font-semibold uppercase tracking-wider text-[var(--muted)]">
                {s.label}
              </p>
            </motion.div>
          ))}
        </div>

        <div className="mt-7 flex w-full max-w-lg flex-col gap-3 sm:flex-row">
          <button
            onClick={onRetry}
            className="group accent-ring flex flex-1 cursor-pointer items-center justify-center gap-2.5 rounded-2xl px-6 py-4 font-display text-base font-bold transition-transform duration-200 active:scale-[0.98]"
            style={{
              backgroundColor: diffHex,
              color: diffId === "medio" ? "#171205" : "#fff",
              boxShadow: `0 16px 40px -16px ${diffHex}`,
            }}
          >
            <RefreshCcw
              size={18}
              strokeWidth={2.4}
              className="transition-transform duration-500 group-hover:-rotate-180"
            />
            {t.retry}
          </button>
          <button
            onClick={onNewTopic}
            className="accent-ring flex flex-1 cursor-pointer items-center justify-center gap-2.5 rounded-2xl border border-[var(--line)] bg-[var(--card)] px-6 py-4 font-display text-base font-bold transition-all duration-200 hover:border-[color-mix(in_srgb,var(--fg)_35%,transparent)] active:scale-[0.98]"
          >
            <ArrowLeft size={18} strokeWidth={2.4} />
            {t.newTopic}
          </button>
        </div>
      </motion.div>

      {/* -------- repaso -------- */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.45, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      >
        <h3 className="mb-4 text-[11px] font-bold uppercase tracking-[0.22em] text-[var(--muted)]">
          {t.review}
        </h3>
        <div className="flex flex-col gap-3">
          {quiz.questions.map((q, i) => {
            const ans = answers[i];
            const ok = ans === q.correcta;
            const color = ok ? GREEN : RED;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                className="rounded-2xl border border-[var(--line)] bg-[var(--card)] p-4 sm:p-5"
                style={{ borderLeft: `4px solid ${color}` }}
              >
                <div className="mb-2 flex items-start gap-3">
                  <span
                    className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-xs font-bold"
                    style={{ backgroundColor: `color-mix(in srgb, ${color} 15%, transparent)`, color }}
                  >
                    {i + 1}
                  </span>
                  <div>
                    <span className="mb-1 inline-block rounded-full border border-[var(--line)] px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">
                      {q.tipo === "vf" ? t.typeVfShort : t.typeMc}
                    </span>
                    <p className="font-display text-[15px] font-semibold leading-snug sm:text-base">
                      {q.pregunta}
                    </p>
                  </div>
                </div>
                <div className="ml-10 flex flex-col gap-1 text-sm">
                  <p style={{ color }}>
                    <span className="font-semibold">{t.yourAnswer}:</span>{" "}
                    {ans >= 0 ? q.opciones[ans] : t.noAnswer}
                  </p>
                  {!ok && (
                    <p style={{ color: GREEN }}>
                      <span className="font-semibold">{t.correctAnswer}:</span> {q.opciones[q.correcta]}
                    </p>
                  )}
                  <p className="mt-1 text-xs leading-relaxed text-[var(--muted)]">{q.explicacion}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
}
