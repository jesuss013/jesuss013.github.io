import { AnimatePresence, motion } from "framer-motion";
import { Check as CheckIcon, ChevronDown, Globe, Languages } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { LANGS, type Lang } from "../lib/i18n";

interface Props {
  lang: Lang;
  onChange: (l: Lang) => void;
  label: string;
}

export default function LanguageSwitcher({ lang, onChange, label }: Props) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);
  const btnRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const close = (e: Event) => {
      const target = e.target as Node;
      // ignora clics dentro del propio widget (el botón ya abre/cierra por sí mismo)
      if (wrapRef.current?.contains(target)) return;
      setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    // 'click' en lugar de 'mousedown': captura también pulsaciones táctiles
    window.addEventListener("click", close, true);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("click", close, true);
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const current = LANGS.find((l) => l.code === lang)!;

  return (
    <div ref={wrapRef} className="relative">
      <button
        ref={btnRef}
        onClick={() => setOpen((v) => !v)}
        aria-label={label}
        aria-haspopup="listbox"
        aria-expanded={open}
        className="accent-ring flex h-11 cursor-pointer items-center gap-2 rounded-full border border-[var(--line)] bg-[var(--card)] px-3.5 text-sm font-semibold text-[var(--fg)] transition-all duration-300 hover:scale-105 hover:border-[color-mix(in_srgb,var(--fg)_30%,transparent)] active:scale-95"
      >
        <Languages size={16} className="text-[var(--muted)]" />
        <span className="tabular-nums">{current.native}</span>
        <ChevronDown
          size={14}
          className={`text-[var(--muted)] transition-transform duration-300 ${open ? "rotate-180" : ""}`}
        />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.97 }}
            transition={{ duration: 0.16, ease: [0.22, 1, 0.36, 1] }}
            role="listbox"
            aria-label={label}
            className="absolute right-0 top-[calc(100%+8px)] z-[60] w-48 origin-top-right overflow-hidden rounded-2xl border border-[var(--line)] bg-[var(--card)] p-1.5 shadow-[0_24px_60px_-12px_rgba(0,0,0,0.45)]"
          >
            {LANGS.map((l) => {
              const active = l.code === lang;
              return (
                <button
                  key={l.code}
                  role="option"
                  aria-selected={active}
                  onClick={() => {
                    onChange(l.code);
                    setOpen(false);
                  }}
                  className={`flex w-full cursor-pointer items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-left text-sm transition-colors duration-200 ${
                    active
                      ? "bg-[color-mix(in_srgb,var(--fg)_8%,transparent)] font-semibold text-[var(--fg)]"
                      : "text-[var(--muted)] hover:bg-[color-mix(in_srgb,var(--fg)_5%,transparent)] hover:text-[var(--fg)]"
                  }`}
                >
                  <span className="flex items-center gap-2.5">
                    <Globe size={14} className="opacity-60" />
                    {l.label}
                  </span>
                  {active && <CheckIcon size={14} />}
                </button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
