import { getLocalizedBanks } from "./bank";
import { T, VF_LABELS, type Lang } from "./i18n";
import type { BankRow, DifficultyId, DifficultyIdx, Question, QuizPayload } from "./types";

/* ---------------------------------- utils ---------------------------------- */

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function normalize(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

export interface DiffSpec {
  id: DifficultyId;
  idx: DifficultyIdx;
}

/* ------------------------------ prompt building ----------------------------- */

const LANG_NAME: Record<Lang, string> = {
  es: "español",
  en: "English",
  pt: "português",
};

function systemPrompt(lang: Lang): string {
  return (
    `You are an expert teacher who creates quizzes. You reply ONLY with valid JSON, no markdown, no code fences, no extra text. Everything must be written in ${LANG_NAME[lang]}.`
  );
}

function buildUserPrompt(topic: string, count: number, diff: DiffSpec, lang: Lang): string {
  const t = T[lang];
  const [vLabel, fLabel] = VF_LABELS[lang];
  const minVf =
    count >= 4
      ? 'Include AT LEAST 1 question of type "vf" (up to 25% of the total). '
      : "";
  return (
    `Create a quiz with exactly ${count} questions about the topic: "${topic}".\n` +
    `Difficulty level "${T[lang].diff[diff.id].label}": ${t.diff[diff.id].hint}.\n` +
    "Question types (mix them in RANDOM positions inside the array):\n" +
    `- "opciones": multiple choice with exactly 4 options and one correct answer. Plausible distractors.\n` +
    `- "vf": true or false. "pregunta" is an affirmative statement (do not include the words "${vLabel}" or "${fLabel}" inside it). ` +
    `"opciones" must be exactly ["${vLabel}","${fLabel}"] and "correcta" is 0 (${vLabel}) or 1 (${fLabel}).\n` +
    minVf +
    "Requirements:\n" +
    "- Varied questions, no repetitions.\n" +
    "- Each question includes a brief explanation (max 180 characters) justifying the answer.\n" +
    `- Everything written in ${LANG_NAME[lang]}.\n` +
    `Exact JSON format: {"preguntas":[{"tipo":"opciones","pregunta":"...","opciones":["...","...","...","..."],"correcta":0,"explicacion":"..."},{"tipo":"vf","pregunta":"statement.","opciones":["${vLabel}","${fLabel}"],"correcta":0,"explicacion":"..."}]}\n` +
    'In "opciones" questions, "correcta" is the index (0-3) of the correct option.'
  );
}

/* --------------------------------- parsing ---------------------------------- */

function extractJson(text: string): unknown {
  let t = text.trim();
  const fence = t.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) t = fence[1].trim();
  try {
    return JSON.parse(t);
  } catch {
    const start = t.indexOf("{");
    const end = t.lastIndexOf("}");
    if (start >= 0 && end > start) {
      return JSON.parse(t.slice(start, end + 1));
    }
    throw new Error("Respuesta sin JSON");
  }
}

function coerceIndex(raw: unknown, options: string[]): number | null {
  if (typeof raw === "number" && Number.isFinite(raw)) {
    let i = Math.trunc(raw);
    if (i > options.length - 1) i = i - 1;
    if (i >= 0 && i < options.length) return i;
  }
  if (typeof raw === "string") {
    const s = raw.trim();
    const letter = /^([a-dA-D])/.exec(s);
    if (letter) {
      const i = letter[1].toLowerCase().charCodeAt(0) - 97;
      if (i >= 0 && i < options.length) return i;
    }
    const n = parseInt(s, 10);
    if (!Number.isNaN(n)) {
      const i = n > options.length - 1 ? n - 1 : n;
      if (i >= 0 && i < options.length) return i;
    }
    const target = normalize(s);
    const hit = options.findIndex((o) => normalize(o) === target);
    if (hit >= 0) return hit;
  }
  return null;
}

/** devuelve 0 = Verdadero/True, 1 = Falso/False */
function coerceBoolish(raw: unknown, lang: Lang): number | null {
  if (typeof raw === "boolean") return raw ? 0 : 1;
  const s = normalize(String(raw ?? "")).trim();
  const [vLabel, fLabel] = VF_LABELS[lang];
  const tSet = new Set(
    ["verdadero", "true", "v", "t", "cierto", "si", "verdadeiro", "correcto", "sim"].map(normalize)
  );
  tSet.add(normalize(vLabel));
  const fSet = new Set(["falso", "false", "f", "incorrecto", "nao", "no"].map(normalize));
  fSet.add(normalize(fLabel));
  if (tSet.has(s)) return 0;
  if (fSet.has(s)) return 1;
  if (s === "0") return 0;
  if (s === "1") return 1;
  return null;
}

function cleanExplanation(raw: unknown, fallback: string): string {
  let e = String(raw ?? "").trim();
  if (e.length > 220) e = e.slice(0, 217) + "…";
  return e || fallback;
}

function sanitizeQuestions(data: unknown, count: number, lang: Lang): Question[] {
  const [vLabel, fLabel] = VF_LABELS[lang];
  const root = data as Record<string, unknown>;
  const arr = Array.isArray(root?.preguntas)
    ? root.preguntas
    : Array.isArray(data)
      ? (data as unknown[])
      : [];
  const out: Question[] = [];
  const seen = new Set<string>();

  for (const item of arr) {
    if (out.length >= count) break;
    const q = item as Record<string, unknown>;
    let pregunta = String(q?.pregunta ?? q?.question ?? "").trim();
    const opcionesRaw = Array.isArray(q?.opciones) ? q.opciones.map((o) => String(o).trim()) : [];
    if (!pregunta) continue;

    const dedupKey = normalize(pregunta).slice(0, 64);
    if (seen.has(dedupKey)) continue;

    const tipoRaw = normalize(String(q?.tipo ?? ""));
    const looksVf =
      tipoRaw.startsWith("vf") ||
      tipoRaw.includes("verdadero") ||
      tipoRaw.includes("true") ||
      tipoRaw.includes("verdadeiro") ||
      (opcionesRaw.length === 2 &&
        opcionesRaw.some((o) => [vLabel, fLabel].map(normalize).includes(normalize(o))));

    if (looksVf) {
      let ci = coerceBoolish(q?.correcta ?? q?.respuesta ?? q?.answer ?? q?.correct, lang);
      if (ci === null && opcionesRaw.length === 2) {
        const idx = coerceIndex(q?.correcta ?? q?.respuesta ?? q?.answer, opcionesRaw);
        if (idx !== null) ci = normalize(opcionesRaw[idx]) === normalize(fLabel) ? 1 : 0;
      }
      if (ci === null) continue;
      pregunta = pregunta
        .replace(/^afirmaci[oó]n\s*:\s*/i, "")
        .replace(/^enunciado\s*:\s*/i, "")
        .replace(/^statement\s*:\s*/i, "");
      if (!/[.!?…]$/.test(pregunta)) pregunta += ".";
      seen.add(dedupKey);
      out.push({
        tipo: "vf",
        pregunta,
        opciones: [vLabel, fLabel],
        correcta: ci,
        explicacion: cleanExplanation(
          q?.explicacion ?? q?.explicación ?? q?.explanation,
          ci === 0 ? T[lang].vfFallbackTrue : T[lang].vfFallbackFalse
        ),
      });
      continue;
    }

    if (opcionesRaw.length < 3) continue;
    const opciones = opcionesRaw.slice(0, 4).filter(Boolean);
    while (opciones.length < 4) opciones.push(lang === "es" ? "Ninguna de las anteriores" : lang === "pt" ? "Nenhuma das anteriores" : "None of the above");
    const keys = opciones.map(normalize);
    if (new Set(keys).size !== opciones.length) continue;

    const correcta = coerceIndex(q?.correcta ?? q?.respuesta ?? q?.answer ?? q?.correct, opciones);
    if (correcta === null) continue;
    seen.add(dedupKey);

    const withIdx = opciones.map((text, i) => ({ text, i }));
    const shuffled = shuffle(withIdx);
    out.push({
      tipo: "opciones",
      pregunta,
      opciones: shuffled.map((s) => s.text),
      correcta: shuffled.findIndex((s) => s.i === correcta),
      explicacion: cleanExplanation(
        q?.explicacion ?? q?.explicación ?? q?.explanation,
        `La respuesta correcta es “${opciones[correcta]}”.`
      ),
    });
  }
  return out;
}

/* ----- conversión de emergencia MC -> VF ----- */

function toVf(q: Question, lang: Lang): Question | null {
  if (q.tipo !== "opciones") return null;
  const patterns =
    lang === "es"
      ? [/[¿]?\s*cu[aá]l\s+(es|fue|era|son|fueron)\s+(.+?)\s*\?\s*$/i]
      : [/^what\s+(.+?)\s*\?\s*$/i];
  for (const re of patterns) {
    const m = re.exec(q.pregunta);
    if (!m) continue;
    const correctOpt = q.opciones[q.correcta];
    const wrongs = q.opciones.filter((_, i) => i !== q.correcta);
    if (!correctOpt || wrongs.length === 0) return null;
    const makeTrue = Math.random() < 0.5;
    const chosen = makeTrue ? correctOpt : wrongs[Math.floor(Math.random() * wrongs.length)];
    const rest = (lang === "es" ? m[2] : m[1]).trim();
    const restCap = rest.charAt(0).toUpperCase() + rest.slice(1);
    const verb = lang === "es" ? ` ${m[1]} ` : " ";
    const falseExp =
      lang === "es"
        ? `Falso: ${rest} ${m[1]} ${correctOpt}. ${q.explicacion}`
        : `False: ${rest} ${correctOpt}. ${q.explicacion}`;
    return {
      tipo: "vf",
      pregunta: `${restCap}${verb}${chosen}.`,
      opciones: VF_LABELS[lang] as unknown as string[],
      correcta: makeTrue ? 0 : 1,
      explicacion: makeTrue ? q.explicacion : falseExp,
    };
  }
  return null;
}

function ensureAtLeastOneVf(questions: Question[], count: number, lang: Lang): Question[] {
  if (count < 4 || questions.some((x) => x.tipo === "vf")) return questions;
  if (lang === "pt") return questions;
  const next = [...questions];
  for (const idx of shuffle(questions.map((_, i) => i))) {
    const conv = toVf(questions[idx], lang);
    if (conv) {
      next[idx] = conv;
      break;
    }
  }
  return next;
}

/* ------------------------------- AI endpoints ------------------------------- */

const TIMEOUT_MS = 45_000;

async function fetchWithTimeout(input: RequestInfo, init: RequestInit, timeout = TIMEOUT_MS) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  try {
    return await fetch(input, { ...init, signal: controller.signal, referrerPolicy: "no-referrer" });
  } finally {
    clearTimeout(id);
  }
}

async function tryOpenAICompat(prompt: string, lang: Lang): Promise<string> {
  const res = await fetchWithTimeout("https://text.pollinations.ai/openai", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "openai",
      messages: [
        { role: "system", content: systemPrompt(lang) },
        { role: "user", content: prompt },
      ],
      response_format: { type: "json_object" },
      seed: Math.floor(Math.random() * 1e9),
    }),
  });
  if (!res.ok) throw new Error("HTTP " + res.status);
  const json = await res.json();
  const content = json?.choices?.[0]?.message?.content;
  if (!content) throw new Error("sin contenido");
  return String(content);
}

async function tryPlainPost(prompt: string, lang: Lang): Promise<string> {
  const res = await fetchWithTimeout("https://text.pollinations.ai/", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "openai",
      jsonMode: true,
      messages: [
        { role: "system", content: systemPrompt(lang) },
        { role: "user", content: prompt },
      ],
      seed: Math.floor(Math.random() * 1e9),
    }),
  });
  if (!res.ok) throw new Error("HTTP " + res.status);
  return await res.text();
}

async function tryPlainGet(prompt: string, lang: Lang): Promise<string> {
  const full = `${systemPrompt(lang)}\n\n${prompt}`;
  const url =
    "https://text.pollinations.ai/" +
    encodeURIComponent(full) +
    "?model=openai&seed=" +
    Math.floor(Math.random() * 1e9) +
    "&referrer=quizmind";
  const res = await fetchWithTimeout(url, { method: "GET" });
  if (!res.ok) throw new Error("HTTP " + res.status);
  return await res.text();
}

/* -------------------------------- local bank -------------------------------- */

function mcFromRow(row: BankRow): Question {
  const [, correct, d1, d2, d3, , exp] = row;
  const opts = shuffle([correct, d1, d2, d3]);
  return {
    tipo: "opciones",
    pregunta: row[0],
    opciones: opts,
    correcta: opts.indexOf(correct),
    explicacion: exp,
  };
}

function pickFromBank(topic: string, count: number, diff: DiffSpec, lang: Lang): QuizPayload {
  const banks = getLocalizedBanks(lang);
  const t = normalize(topic);
  let best = banks[0];
  let bestScore = 0;
  for (const bank of banks) {
    let score = 0;
    for (const kw of bank.keywords) {
      if (kw && t.includes(kw)) score += kw.length;
    }
    if (score > bestScore) {
      bestScore = score;
      best = bank;
    }
  }

  const target = diff.idx as number;
  const [vLabel, fLabel] = VF_LABELS[lang];
  const entries: { q: Question; dif: number }[] = [
    ...best.rows.map((r) => ({ q: mcFromRow(r), dif: r[5] as number })),
    ...best.vfRows.map((r) => ({
      q: {
        tipo: "vf" as const,
        pregunta: r[0],
        opciones: [vLabel, fLabel],
        correcta: r[1] ? 0 : 1,
        explicacion: r[3],
      },
      dif: r[2] as number,
    })),
  ];

  const exact = shuffle(entries.filter((e) => e.dif === target));
  const adjacent = shuffle(entries.filter((e) => Math.abs(e.dif - target) === 1));
  const rest = shuffle(entries.filter((e) => Math.abs(e.dif - target) > 1));
  const pool = [...exact, ...adjacent, ...rest];

  const chosen = pool.slice(0, count);
  while (chosen.length < count && pool.length > 0) {
    chosen.push(pool[chosen.length % pool.length]);
  }

  if (count >= 4 && !chosen.some((e) => e.q.tipo === "vf")) {
    const vf = pool.find((e) => e.q.tipo === "vf");
    if (vf && chosen.length > 0) {
      chosen[Math.floor(Math.random() * chosen.length)] = vf;
    }
  }

  return { questions: shuffle(chosen.map((e) => e.q)), source: "local", bankTitle: best.title };
}

/* --------------------------------- public API ------------------------------- */

export type ProgressFn = (step: number, total: number) => void;

export async function generateQuiz(
  topic: string,
  count: number,
  diff: DiffSpec,
  lang: Lang,
  onProgress?: ProgressFn
): Promise<QuizPayload> {
  const prompt = buildUserPrompt(topic, count, diff, lang);
  const strategies: ((p: string, l: Lang) => Promise<string>)[] = [tryOpenAICompat, tryPlainPost, tryPlainGet];

  let firstError: unknown = null;
  for (let s = 0; s < strategies.length; s++) {
    onProgress?.(s + 1, strategies.length);
    try {
      const raw = await strategies[s](prompt, lang);
      const parsed = extractJson(raw);
      let questions = sanitizeQuestions(parsed, count, lang);
      const min = Math.min(count, Math.max(3, Math.floor(count * 0.5)));
      if (questions.length >= min) {
        questions = ensureAtLeastOneVf(questions, count, lang);
        return { questions: shuffle(questions), source: "ai" };
      }
      throw new Error("preguntas insuficientes: " + questions.length);
    } catch (err) {
      if (firstError === null) firstError = err;
      console.warn(`[QuizMind] estrategia ${s + 1} falló:`, err);
    }
  }

  console.warn("[QuizMind] IA no disponible, usando banco local.", firstError);
  return pickFromBank(topic, count, diff, lang);
}
