export type DifficultyId = "facil" | "medio" | "dificil";

/** 0 = fácil, 1 = medio, 2 = difícil */
export type DifficultyIdx = 0 | 1 | 2;

/** "opciones" = elección múltiple · "vf" = verdadero o falso */
export type QuestionType = "opciones" | "vf";

export interface Question {
  tipo: QuestionType;
  pregunta: string;
  /** en "vf" siempre es ["Verdadero", "Falso"] */
  opciones: string[];
  /** índice de la opción correcta dentro de `opciones` */
  correcta: number;
  explicacion: string;
}

export interface QuizPayload {
  questions: Question[];
  source: "ai" | "local";
  bankTitle?: string;
}

export interface DifficultyMeta {
  id: DifficultyId;
  idx: DifficultyIdx;
  label: string;
  hex: string;
  desc: string;
  aiHint: string;
}

export const DIFFICULTIES: DifficultyMeta[] = [
  {
    id: "facil",
    idx: 0,
    label: "Fácil",
    hex: "#22c55e",
    desc: "Conceptos básicos y datos muy conocidos.",
    aiHint:
      "preguntas sencillas: definiciones, datos muy conocidos y conceptos básicos que casi cualquier aficionado al tema conocería",
  },
  {
    id: "medio",
    idx: 1,
    label: "Medio",
    hex: "#eab308",
    desc: "Relaciones, detalles y datos menos evidentes.",
    aiHint:
      "preguntas de nivel intermedio: relaciones entre conceptos, causas y consecuencias, comparaciones y datos menos evidentes",
  },
  {
    id: "dificil",
    idx: 2,
    label: "Difícil",
    hex: "#ef4444",
    desc: "Conocimiento especializado y distractores tramposos.",
    aiHint:
      "preguntas de nivel experto: datos especializados, fechas exactas, detalles poco conocidos y distractores muy plausibles",
  },
];

/** fila del banco local de opción múltiple: [pregunta, opciónCorrecta, d1, d2, d3, dificultad, explicación] */
export type BankRow = [string, string, string, string, string, DifficultyIdx, string];

/** fila de verdadero/falso: [enunciado, esVerdadero, dificultad, explicación] */
export type VfRow = [string, boolean, DifficultyIdx, string];

export interface LocalBank {
  id: string;
  title: string;
  keywords: string[];
  rows: BankRow[];
  vfRows: VfRow[];
}
