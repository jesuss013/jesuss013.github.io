import type { BankRow, LocalBank, VfRow } from "./types";
import type { Lang } from "./i18n";

/* ----------------------------- filas en español ---------------------------- */

interface BankDef {
  id: string;
  keywords: string[];
  rows: BankRow[];
  vfRows: VfRow[];
  tr: [(string | null)[], (string | null)[]];
}

function bank(
  id: string,
  keywords: string[],
  rows: BankRow[],
  vfRows: VfRow[],
  tr: [(string | null)[], (string | null)[]]
): BankDef {
  return { id, keywords, rows, vfRows, tr };
}

const GENERAL = bank(
  "general",
  [],
  [
    ["¿Cuántos planetas tiene el sistema solar?", "8", "7", "9", "10", 0, "Tras la reclasificación de Plutón en 2006 quedaron 8 planetas."],
    ["¿Cuál es el océano más grande del mundo?", "Océano Pacífico", "Océano Atlántico", "Océano Índico", "Océano Ártico", 0, "El Pacífico cubre cerca de un tercio de la superficie terrestre."],
    ["¿Qué gas respiramos principalmente para vivir?", "Oxígeno", "Dióxido de carbono", "Nitrógeno", "Hidrógeno", 0, "El oxígeno es esencial para la respiración celular."],
    ["¿En qué continente está Egipto?", "África", "Asia", "Europa", "América", 0, "Egipto se ubica en el noreste de África (con el Sinaí en Asia)."],
    ["¿Cuántos días tiene un año bisiesto?", "366", "365", "364", "360", 0, "Se añade el 29 de febrero cada cuatro años, con excepciones."],
    ["¿Qué órgano del cuerpo humano bombea la sangre?", "El corazón", "El hígado", "Los pulmones", "El cerebro", 0, "El corazón impulsa la sangre por todo el sistema circulatorio."],
    ["¿Quién pintó la 'Mona Lisa'?", "Leonardo da Vinci", "Miguel Ángel", "Rafael Sanzio", "Vincent van Gogh", 1, "Da Vinci la pintó a principios del siglo XVI."],
    ["¿Cuál es el ave más grande del mundo?", "El avestruz", "El águila real", "El cóndor andino", "El albatros", 1, "El avestruz puede medir hasta 2,7 metros de altura."],
    ["¿En qué año llegó el ser humano a la Luna?", "1969", "1959", "1975", "1981", 1, "El Apolo 11 alunizó el 20 de julio de 1969."],
    ["¿Cuál es el río más largo de Europa?", "El Volga", "El Danubio", "El Rin", "El Támesis", 1, "El Volga, en Rusia, supera los 3.500 km de longitud."],
    ["¿Qué elemento químico tiene el símbolo 'Au'?", "Oro", "Plata", "Aluminio", "Argón", 2, "Au viene del latín 'aurum', que significa oro."],
    ["¿Quién pintó 'La escuela de Atenas'?", "Rafael Sanzio", "Miguel Ángel", "Leonardo da Vinci", "Botticelli", 2, "Es un fresco de Rafael en las Estancias Vaticanas (1509-1511)."],
  ],
  [
    ["Los delfines son mamíferos.", true, 0, "Respiran aire y amamantan a sus crías, como todos los mamíferos."],
    ["El Sol gira alrededor de la Tierra.", false, 0, "Es la Tierra la que orbita alrededor del Sol."],
    ["El ser humano tiene cinco sentidos principales.", true, 0, "Vista, oído, olfato, gusto y tacto."],
    ["La Gran Muralla China se ve a simple vista desde la Luna.", false, 2, "Es un mito: es demasiado estrecha para apreciarse a esa distancia."],
  ],
  [
    [
      null,
      "How many planets are there in the solar system?|8|7|9|10||After Pluto was reclassified in 2006, eight planets remained.",
      "What is the largest ocean in the world?|Pacific Ocean|Atlantic Ocean|Indian Ocean|Arctic Ocean||The Pacific covers about one third of Earth's surface.",
      "Which gas do we mainly breathe to live?|Oxygen|Carbon dioxide|Nitrogen|Hydrogen||Oxygen is essential for cellular respiration.",
      "On which continent is Egypt?|Africa|Asia|Europe|America||Egypt lies in northeastern Africa (with Sinai in Asia).",
      "How many days does a leap year have?|366|365|364|360||February 29 is added, with centenary exceptions.",
      "Which organ of the human body pumps blood?|The heart|The liver|The lungs|The brain||The heart drives blood through the circulatory system.",
      "Who painted the 'Mona Lisa'?|Leonardo da Vinci|Michelangelo|Raphael|Vincent van Gogh||Da Vinci painted it in the early 16th century.",
      "What is the largest bird in the world?|The ostrich|The golden eagle|The Andean condor|The albatross||The ostrich can reach 2.7 metres tall.",
      "In which year did humans first land on the Moon?|1969|1959|1975|1981||Apollo 11 landed on July 20, 1969.",
      "What is the longest river in Europe?|The Volga|The Danube|The Rhine|The Thames||Russia's Volga is over 3,500 km long.",
      "Which chemical element has the symbol 'Au'?|Gold|Silver|Aluminium|Argon||Au comes from the Latin 'aurum', meaning gold.",
      "Who painted 'The School of Athens'?|Raphael|Michelangelo|Leonardo da Vinci|Botticelli||It is a Raphael fresco in the Vatican Rooms (1509-1511).",
    ],
    [
      null,
      "Dolphins are mammals.||Dolphins?|They breathe air and nurse their young, like all mammals.",
      "The Sun revolves around the Earth.||Earth orbit|It is the Earth that orbits the Sun.",
      "Humans have five main senses.||Senses|Sight, hearing, smell, taste and touch.",
      "The Great Wall of China can be seen with the naked eye from the Moon.||Great Wall myth|It's a myth: it is far too narrow to be seen from that distance.",
    ],
  ]
);

const HISTORIA = bank(
  "historia",
  ["historia", "guerra", "imperio", "roma", "romano", "egipto", "revolucion", "vikingo", "medieval", "fenicio", "maya", "inca", "azteca", "grecia", "napoleon", "colon", "descubrimiento"],
  [
    ["¿En qué año comenzó la Segunda Guerra Mundial?", "1939", "1914", "1941", "1945", 0, "Inició el 1 de septiembre de 1939 con la invasión alemana de Polonia."],
    ["¿Quién fue el primer presidente de Estados Unidos?", "George Washington", "Abraham Lincoln", "Thomas Jefferson", "John Adams", 0, "Washington gobernó de 1789 a 1797."],
    ["¿Qué civilización construyó las pirámides de Giza?", "Los egipcios", "Los mayas", "Los romanos", "Los griegos", 0, "Fueron levantadas como tumbas faraónicas hacia el 2500 a. C."],
    ["¿Qué imperio gobernó Julio César?", "El Imperio romano", "El Imperio griego", "El Imperio otomano", "El Imperio persa", 0, "César fue cónsul y dictador de Roma en el siglo I a. C."],
    ["¿Qué muro cayó en 1989?", "El Muro de Berlín", "La Gran Muralla China", "El Muro de Adriano", "Las murallas de Ávila", 0, "Su caída simbolizó el fin de la Guerra Fría."],
    ["¿En qué año llegó Cristóbal Colón a América?", "1492", "1500", "1482", "1510", 1, "Arribó a Guanahani (Bahamas) el 12 de octubre de 1492."],
    ["¿Qué evento de 1789 marcó el inicio de la Revolución francesa?", "La toma de la Bastilla", "La ejecución de Luis XVI", "El golpe de Napoleón", "La Declaración de Derechos de Virginia", 1, "Ocurrió el 14 de julio de 1789."],
    ["¿Qué tratado puso fin formalmente a la Primera Guerra Mundial?", "El Tratado de Versalles", "El Tratado de París", "El Tratado de Tordesillas", "El Tratado de Utrecht", 1, "Firmado en 1919, impuso duras condiciones a Alemania."],
    ["¿Qué emperador romano legalizó el cristianismo en el año 313?", "Constantino I", "Nerón", "Trajano", "Augusto", 2, "Con el Edicto de Milán otorgó libertad de culto."],
    ["¿Qué dinastía gobernó China al construirse la mayor parte de la Gran Muralla actual?", "Ming", "Qin", "Han", "Song", 2, "La muralla visible hoy data sobre todo de la dinastía Ming (1368-1644)."],
    ["¿Qué batalla de 1815 significó la derrota definitiva de Napoleón?", "Waterloo", "Austerlitz", "Trafalgar", "Borodinó", 2, "Napoleón fue derrotado en Waterloo por fuerzas británicas y prusianas."],
    ["¿Qué pueblo antiguo inventó el primer alfabeto de amplia difusión?", "Los fenicios", "Los hititas", "Los sumerios", "Los etruscos", 2, "El alfabeto fenicio es base del griego, latino y hebreo."],
  ],
  [
    ["Colón llegó a América en 1492.", true, 0, "Arribó a las Bahamas el 12 de octubre de 1492."],
    ["La Segunda Guerra Mundial duró más de 10 años.", false, 0, "Duró 6 años: de 1939 a 1945."],
    ["La Primera Guerra Mundial terminó en 1918.", true, 1, "El armisticio se firmó el 11 de noviembre de 1918."],
    ["Napoleón Bonaparte nació en París.", false, 2, "Nació en Ajaccio, Córcega, en 1769."],
    ["Los vikingos llegaron a América antes que Colón.", true, 2, "Leif Erikson fundó asentamientos en Terranova hacia el año 1000."],
  ],
  [
    [
      null,
      "In which year did World War II begin?|1939|1914|1941|1945||It began on September 1, 1939 with the German invasion of Poland.",
      "Who was the first President of the United States?|George Washington|Abraham Lincoln|Thomas Jefferson|John Adams||Washington served from 1789 to 1797.",
      "Which civilization built the pyramids of Giza?|The Egyptians|The Mayans|The Romans|The Greeks||They were raised as pharaonic tombs around 2500 BC.",
      "Which empire did Julius Caesar rule?|The Roman Empire|The Greek Empire|The Ottoman Empire|The Persian Empire||Caesar was consul and dictator of Rome in the 1st century BC.",
      "Which wall fell in 1989?|The Berlin Wall|The Great Wall of China|Hadrian's Wall|The walls of Ávila||Its fall symbolized the end of the Cold War.",
      "In which year did Christopher Columbus reach the Americas?|1492|1500|1482|1510||He arrived at Guanahani (Bahamas) on October 12, 1492.",
      "Which 1789 event marked the start of the French Revolution?|The storming of the Bastille|The execution of Louis XVI|Napoleon's coup|The Virginia Declaration of Rights||It happened on July 14, 1789.",
      "Which treaty formally ended World War I?|The Treaty of Versailles|The Treaty of Paris|The Treaty of Tordesillas|The Treaty of Utrecht||Signed in 1919, it imposed harsh conditions on Germany.",
      "Which Roman emperor legalized Christianity in the year 313?|Constantine I|Nero|Trajan|Augustus||The Edict of Milan granted freedom of worship.",
      "Which dynasty ruled China when most of today's Great Wall was built?|Ming|Qin|Han|Song||The visible wall dates mostly from the Ming dynasty (1368-1644).",
      "Which 1815 battle meant Napoleon's final defeat?|Waterloo|Austerlitz|Trafalgar|Borodino||Napoleon was defeated by British and Prussian forces at Waterloo.",
      "Which ancient people invented the first widely-spread alphabet?|The Phoenicians|The Hittites|The Sumerians|The Etruscans||The Phoenician alphabet is the base of the Greek, Latin and Hebrew scripts.",
    ],
    [
      null,
      "Columbus reached the Americas in 1492.||Columbus 1492|He arrived in the Bahamas on October 12, 1492.",
      "World War II lasted more than 10 years.||WWII|It lasted 6 years: from 1939 to 1945.",
      "World War I ended in 1918.||WWI|The armistice was signed on November 11, 1918.",
      "Napoleon Bonaparte was born in Paris.||Napoleon|He was born in Ajaccio, Corsica, in 1769.",
      "The Vikings reached America before Columbus.||Vikings|Leif Erikson founded settlements in Newfoundland around the year 1000.",
    ],
  ]
);

const GEOGRAFIA = bank(
  "geografia",
  ["geografia", "paises", "capitales", "rio", "montana", "continente", "mapa", "oceano", "isla", "ciudad", "europa", "asia", "america", "africa", "oceania", "desierto"],
  [
    ["¿Cuál es la capital de Francia?", "París", "Lyon", "Marsella", "Niza", 0, "París es la capital y la ciudad más poblada de Francia."],
    ["¿Cuál es el país más grande del mundo por superficie?", "Rusia", "China", "Canadá", "Estados Unidos", 0, "Rusia abarca más de 17 millones de km²."],
    ["¿En qué país está el monte Everest?", "Nepal", "Suiza", "Chile", "Marruecos", 0, "El Everest está en la frontera entre Nepal y China (Tíbet)."],
    ["¿Cuál es el desierto cálido más grande del mundo?", "El Sahara", "El Gobi", "El de Atacama", "El de Kalahari", 0, "El Sahara ocupa unos 9 millones de km² en el norte de África."],
    ["¿Qué país europeo tiene forma de bota en el mapa?", "Italia", "España", "Grecia", "Portugal", 0, "La península itálica es famosa por su forma de bota."],
    ["¿Cuál es la capital de Australia?", "Canberra", "Sídney", "Melbourne", "Perth", 1, "Canberra fue elegida como capital de compromiso en 1908."],
    ["¿Qué río atraviesa la ciudad de El Cairo?", "El Nilo", "El Éufrates", "El Congo", "El Níger", 1, "El Nilo fue el eje de la civilización egipcia."],
    ["¿Cuál es el único país que es a la vez un continente?", "Australia", "Groenlandia", "Islandia", "Madagascar", 0, "Australia ocupa todo el continente oceánico."],
    ["¿Qué estrecho separa Europa de África?", "El de Gibraltar", "El de Bering", "El de Ormuz", "El de Malaca", 1, "Tiene apenas 14 km en su punto más angosto."],
    ["¿Cuál es la capital de Canadá?", "Ottawa", "Toronto", "Vancouver", "Montreal", 2, "Ottawa, en Ontario, es la sede del gobierno federal."],
    ["¿Qué país africano fue conocido como Abisinia?", "Etiopía", "Somalia", "Sudán", "Kenia", 2, "Etiopía conservó su independencia salvo la ocupación italiana (1936-1941)."],
    ["¿Cuál es hoy la capital oficial de Kazajistán?", "Astaná", "Almatý", "Taskent", "Biskek", 2, "La capital cambió de Almatý a Astaná (Nursultán entre 2019 y 2022)."],
  ],
  [
    ["El desierto del Sahara está ubicado en Asia.", false, 0, "Está en el norte de África."],
    ["Rusia pertenece a dos continentes.", true, 1, "Los montes Urales dividen su parte europea y asiática."],
    ["El Amazonas es el río más caudaloso del mundo.", true, 1, "Su caudal supera al de los siguientes grandes ríos juntos."],
    ["África es el continente con más países.", true, 2, "Cuenta con 54 países soberanos."],
    ["Japón está formado por una única isla grande.", false, 2, "Es un archipiélago de miles de islas; las principales son Honshu, Hokkaido, Kyushu y Shikoku."],
  ],
  [
    [
      null,
      "What is the capital of France?|Paris|Lyon|Marseille|Nice||Paris is France's capital and most populous city.",
      "What is the largest country in the world by area?|Russia|China|Canada|United States||Russia spans more than 17 million km².",
      "In which country is Mount Everest?|Nepal|Switzerland|Chile|Morocco||Everest lies on the border between Nepal and China (Tibet).",
      "What is the largest hot desert in the world?|The Sahara|The Gobi|The Atacama|The Kalahari||The Sahara covers about 9 million km² in North Africa.",
      "Which European country is shaped like a boot on the map?|Italy|Spain|Greece|Portugal||The Italian peninsula is famous for its boot shape.",
      "What is the capital of Australia?|Canberra|Sydney|Melbourne|Perth||Canberra was chosen as a compromise capital in 1908.",
      "Which river runs through Cairo?|The Nile|The Euphrates|The Congo|The Niger||The Nile was the axis of Egyptian civilization.",
      "Which is the only country that is also a continent?|Australia|Greenland|Iceland|Madagascar||Australia occupies the entire Oceanian continent.",
      "Which strait separates Europe from Africa?|The Strait of Gibraltar|The Bering Strait|The Strait of Hormuz|The Strait of Malacca||It is barely 14 km at its narrowest point.",
      "What is the capital of Canada?|Ottawa|Toronto|Vancouver|Montreal||Ottawa, in Ontario, hosts the federal government.",
      "Which African country was known as Abyssinia?|Ethiopia|Somalia|Sudan|Kenya||Ethiopia kept its independence except for the Italian occupation (1936-1941).",
      "What is the current official capital of Kazakhstan?|Astana|Almaty|Tashkent|Bishkek||The capital moved from Almaty to Astana (called Nur-Sultan between 2019 and 2022).",
    ],
    [
      null,
      "The Sahara Desert is located in Asia.||Saara|It is in northern Africa.",
      "Russia belongs to two continents.||Russia|The Ural Mountains divide its European and Asian parts.",
      "The Amazon is the river with the greatest discharge in the world.||Rio Amazonas|Its flow exceeds that of the next largest rivers combined.",
      "Africa is the continent with the most countries.||África|It has 54 sovereign countries.",
      "Japan is made up of a single large island.||Japão|It is an archipelago of thousands of islands; the main ones are Honshu, Hokkaido, Kyushu and Shikoku.",
    ],
  ]
);

const CIENCIA = bank(
  "ciencia",
  ["ciencia", "fisica", "quimica", "biologia", "espacio", "astronomia", "planeta", "cuerpo humano", "anatomia", "celula", "animal", "matematicas", "universo", "naturaleza", "adn"],
  [
    ["¿Cuál es el planeta más cercano al Sol?", "Mercurio", "Venus", "Marte", "Tierra", 0, "Mercurio completa su órbita en solo 88 días."],
    ["¿Cuál es la fórmula química del agua?", "H₂O", "CO₂", "O₂", "NaCl", 0, "Dos átomos de hidrógeno y uno de oxígeno."],
    ["¿Qué parte de la célula contiene el ADN?", "El núcleo", "La mitocondria", "El ribosoma", "La membrana", 0, "El núcleo almacena el material genético en las células eucariotas."],
    ["¿Cuál es el hueso más grande del cuerpo humano?", "El fémur", "La tibia", "El húmero", "El cráneo", 0, "El fémur es también el hueso más resistente."],
    ["¿Qué planeta es conocido como el planeta rojo?", "Marte", "Júpiter", "Saturno", "Venus", 0, "Su color se debe al óxido de hierro de su superficie."],
    ["¿Qué fuerza mantiene a los planetas orbitando el Sol?", "La gravedad", "El magnetismo", "La fricción", "La fuerza nuclear", 1, "La gravedad del Sol curva el espacio-tiempo y mantiene las órbitas."],
    ["¿Qué gas liberan las plantas durante la fotosíntesis?", "Oxígeno", "Dióxido de carbono", "Nitrógeno", "Metano", 1, "Convierten CO₂ y agua en glucosa liberando O₂."],
    ["¿Aproximadamente a qué velocidad viaja la luz en el vacío?", "300.000 km/s", "30.000 km/s", "3.000 km/s", "3.000.000 km/s", 1, "Son 299.792 km por segundo, constante universal."],
    ["¿Qué partícula subatómica tiene carga negativa?", "El electrón", "El protón", "El neutrón", "El fotón", 1, "Los electrones orbitan el núcleo atómico."],
    ["¿Qué escala se asocia clásicamente con la intensidad de los terremotos?", "La escala de Richter", "La escala Beaufort", "La escala de Mohs", "La escala Celsius", 2, "Aunque hoy se usa la de magnitud de momento, la de Richter sigue como referencia popular."],
    ["¿Qué científica ganó dos premios Nobel en dos ciencias distintas?", "Marie Curie", "Rosalind Franklin", "Ada Lovelace", "Lise Meitner", 2, "Curie ganó el de Física (1903) y el de Química (1911)."],
    ["¿Cuál es el elemento químico más abundante del universo?", "Hidrógeno", "Helio", "Oxígeno", "Carbono", 2, "Alrededor del 75 % de la materia normal es hidrógeno."],
  ],
  [
    ["La luz viaja más rápido que el sonido.", true, 0, "Unos 299.792 km/s frente a 343 m/s del sonido en el aire."],
    ["Los chimpancés son reptiles.", false, 0, "Son mamíferos primates."],
    ["El agua hierve a 100 °C a nivel del mar.", true, 0, "A menor presión atmosférica hierve a menor temperatura."],
    ["Los átomos están compuestos en su mayoría por espacio vacío.", true, 2, "El núcleo ocupa una parte ínfima del volumen del átomo."],
    ["La Tierra tarda un año en orbitar el Sol.", true, 1, "Exactamente 365,25 días, por es existen los años bisiestos."],
  ],
  [
    [
      null,
      "Which planet is closest to the Sun?|Mercury|Venus|Mars|Earth||Mercury completes its orbit in just 88 days.",
      "What is the chemical formula of water?|H₂O|CO₂|O₂|NaCl||Two hydrogen atoms and one oxygen atom.",
      "Which part of the cell contains DNA?|The nucleus|The mitochondrion|The ribosome|The membrane||The nucleus stores genetic material in eukaryotic cells.",
      "What is the largest bone in the human body?|The femur|The tibia|The humerus|The skull||The femur is also the strongest bone.",
      "Which planet is known as the red planet?|Mars|Jupiter|Saturn|Venus||Its colour comes from iron oxide on its surface.",
      "Which force keeps the planets orbiting the Sun?|Gravity|Magnetism|Friction|Nuclear force||The Sun's gravity curves space-time and holds the orbits.",
      "Which gas do plants release during photosynthesis?|Oxygen|Carbon dioxide|Nitrogen|Methane||They turn CO₂ and water into glucose, releasing O₂.",
      "Approximately how fast does light travel in a vacuum?|300,000 km/s|30,000 km/s|3,000 km/s|3,000,000 km/s||It is 299,792 km per second, a universal constant.",
      "Which subatomic particle has a negative charge?|The electron|The proton|The neutron|The photon||Electrons orbit the atomic nucleus.",
      "Which scale is classically associated with earthquake intensity?|The Richter scale|The Beaufort scale|The Mohs scale|The Celsius scale||Although moment magnitude is used today, Richter remains the popular reference.",
      "Which scientist won two Nobel Prizes in two different sciences?|Marie Curie|Rosalind Franklin|Ada Lovelace|Lise Meitner||Curie won Physics (1903) and Chemistry (1911).",
      "What is the most abundant chemical element in the universe?|Hydrogen|Helium|Oxygen|Carbon||About 75% of normal matter is hydrogen.",
    ],
    [
      null,
      "Light travels faster than sound.||Luz|About 299,792 km/s versus 343 m/s for sound in air.",
      "Chimpanzees are reptiles.||Chimpanzés|They are primate mammals.",
      "Water boils at 100 °C at sea level.||Água|At lower atmospheric pressure it boils at a lower temperature.",
      "Atoms are mostly made of empty space.||Átomos|The nucleus occupies a tiny fraction of the atom's volume.",
      "The Earth takes one year to orbit the Sun.||Terra|Exactly 365.25 days, which is why leap years exist.",
    ],
  ]
);

const DEPORTES = bank(
  "deportes",
  ["futbol", "deporte", "olimpiada", "baloncesto", "tenis", "mundial", "nba", "messi", "cristiano", "atletismo", "natacion", "boxeo", "ciclismo", "formula 1"],
  [
    ["¿Cada cuántos años se celebra el Mundial de fútbol?", "Cada 4 años", "Cada 2 años", "Cada 3 años", "Cada 5 años", 0, "La Copa Mundial de la FIFA se juega cada cuatro años desde 1930."],
    ["¿Cuántos jugadores de un equipo de fútbol entran al campo?", "11", "9", "10", "7", 0, "Once titulares, incluido el portero."],
    ["¿Qué país ha ganado más Mundiales de fútbol?", "Brasil", "Alemania", "Argentina", "Italia", 0, "Brasil tiene 5 títulos (1958, 1962, 1970, 1994 y 2002)."],
    ["¿En qué deporte destaca el término 'slam dunk'?", "Baloncesto", "Tenis", "Béisbol", "Voleibol", 0, "Es la famosa 'machacada' o mate del baloncesto."],
    ["¿Cuántos anillos tiene el símbolo olímpico?", "5", "4", "6", "7", 0, "Representan los cinco continentes habitados."],
    ["¿En qué país se originaron los Juegos Olímpicos?", "Grecia", "Italia", "Egipto", "Turquía", 1, "Se celebraban en Olimpia desde el 776 a. C."],
    ["¿Qué tenista español ha ganado 14 Roland Garros?", "Rafael Nadal", "Carlos Alcaraz", "David Ferrer", "Manuel Santana", 1, "Nadal es el 'Rey de la Tierra Batida' con 14 títulos en París."],
    ["¿Cuánto dura un partido de baloncesto NBA?", "48 minutos", "40 minutos", "60 minutos", "45 minutos", 1, "Cuatro cuartos de 12 minutos cada uno."],
    ["¿Qué selección ganó el Mundial de fútbol de 2022?", "Argentina", "Francia", "Brasil", "España", 1, "Argentina venció a Francia en los penaltis en la final de Catar."],
    ["¿Qué longitud tiene un maratón oficial?", "42,195 km", "40 km", "45 km", "38,5 km", 2, "La distancia se fijó en los Juegos de Londres 1908."],
    ["¿Quién es el máximo goleador histórico de los Mundiales de fútbol?", "Miroslav Klose", "Ronaldo Nazário", "Lionel Messi", "Gerd Müller", 2, "El alemán Klose marcó 16 goles en mundiales."],
    ["¿En qué año ganó España su primer Mundial de fútbol?", "2010", "2006", "2014", "1998", 2, "Fue en Sudáfrica 2010, con gol de Iniesta en la prórroga."],
  ],
  [
    ["Un partido de fútbol dura 90 minutos reglamentarios.", true, 0, "Dos tiempos de 45 minutos más el tiempo de descuento."],
    ["Los Juegos Olímpicos de verano se celebran cada 2 años.", false, 0, "Se celebran cada 4 años, alternándose con los de invierno."],
    ["Michael Jordan ganó 6 anillos de la NBA.", true, 1, "Todos con los Chicago Bulls (1991-93 y 1996-98)."],
    ["Todos los partidos de tenis profesional se juegan al mejor de 5 sets.", false, 1, "Solo los Grand Slams masculinos; el resto al mejor de 3."],
    ["El Tour de Francia es una carrera ciclista.", true, 0, "Es la vuelta por etapas más famosa del mundo."],
  ],
  [
    [
      null,
      "How often is the football World Cup held?|Every 4 years|Every 2 years|Every 3 years|Every 5 years||The FIFA World Cup has been played every four years since 1930.",
      "How many players does a football team field?|11|9|10|7||Eleven starters, including the goalkeeper.",
      "Which country has won the most football World Cups?|Brazil|Germany|Argentina|Italy||Brazil has 5 titles (1958, 1962, 1970, 1994 and 2002).",
      "In which sport is the term 'slam dunk' used?|Basketball|Tennis|Baseball|Volleyball||It is the famous basketball dunk.",
      "How many rings does the Olympic symbol have?|5|4|6|7||They represent the five inhabited continents.",
      "In which country did the Olympic Games originate?|Greece|Italy|Egypt|Turkey||They were held in Olympia from 776 BC.",
      "Which Spanish tennis player has won 14 Roland Garros titles?|Rafael Nadal|Carlos Alcaraz|David Ferrer|Manuel Santana||Nadal is the 'King of Clay' with 14 titles in Paris.",
      "How long is an NBA basketball game?|48 minutes|40 minutes|60 minutes|45 minutes||Four 12-minute quarters.",
      "Which national team won the 2022 football World Cup?|Argentina|France|Brazil|Spain||Argentina beat France on penalties in the Qatar final.",
      "What is the official distance of a marathon?|42.195 km|40 km|45 km|38.5 km||The distance was set at the 1908 London Games.",
      "Who is the all-time top scorer of the football World Cups?|Miroslav Klose|Ronaldo Nazário|Lionel Messi|Gerd Müller||Germany's Klose scored 16 World Cup goals.",
      "In which year did Spain win its first football World Cup?|2010|2006|2014|1998||It was in South Africa 2010, with Iniesta's extra-time goal.",
    ],
    [
      null,
      "A football match lasts 90 regulation minutes.||Futebol|Two 45-minute halves plus stoppage time.",
      "The Summer Olympic Games are held every 2 years.||Jogos Olímpicos|They are held every 4 years, alternating with the Winter Games.",
      "Michael Jordan won 6 NBA rings.||Michael Jordan|All of them with the Chicago Bulls (1991-93 and 1996-98).",
      "All professional tennis matches are played best of 5 sets.||Tênis|Only men's Grand Slams; the rest are best of 3.",
      "The Tour de France is a cycling race.||Tour de France|It is the most famous stage race in the world.",
    ],
  ]
);

const CINE = bank(
  "cine",
  ["cine", "pelicula", "serie", "musica", "disney", "marvel", "star wars", "harry potter", "actor", "cantante", "grupo", "rock", "netflix"],
  [
    ["¿Quién dirigió 'Titanic' (1997)?", "James Cameron", "Steven Spielberg", "Christopher Nolan", "Ridley Scott", 0, "Cameron también dirigió 'Avatar' y 'Terminator'."],
    ["¿Qué película ganó el Óscar en 2020 siendo la primera de habla no inglesa?", "Parásitos", "Roma", "1917", "Joker", 0, "La surcoreana 'Parásitos' hizo historia en los Óscar."],
    ["¿Cómo se llama el mago protagonista de la saga de J. K. Rowling?", "Harry Potter", "Ron Weasley", "Albus Dumbledore", "Frodo Bolsón", 0, "La saga comenzó con 'La piedra filosofal' (2001 en cine)."],
    ["¿Qué banda británica cantó 'Bohemian Rhapsody'?", "Queen", "The Beatles", "The Rolling Stones", "Pink Floyd", 0, "Freddie Mercury y Queen la lanzaron en 1975."],
    ["¿Qué película de Disney tiene a una princesa llamada Elsa?", "Frozen", "Enredados", "Vaiana", "Brave", 0, "Elsa, la reina de las nieves, protagoniza 'Frozen' (2013)."],
    ["¿Qué actor interpreta a Iron Man en el Universo Marvel?", "Robert Downey Jr.", "Chris Evans", "Chris Hemsworth", "Mark Ruffalo", 1, "Debutó como Tony Stark en la película de 2008."],
    ["¿Cuántas películas componen la trilogía original de 'Star Wars'?", "3", "2", "4", "6", 1, "Episodios IV, V y VI, estrenados entre 1977 y 1983."],
    ["¿Qué compositor escribió la música de 'Star Wars', 'Indiana Jones' y 'Harry Potter'?", "John Williams", "Hans Zimmer", "Ennio Morricone", "Danny Elfman", 1, "Williams ha ganado 5 Óscar y más de 25 Grammy."],
    ["¿Qué serie de Netflix sigue a un grupo de chicos en Hawkins, Indiana?", "Stranger Things", "Dark", "The Umbrella Academy", "Riverdale", 1, "Estrenada en 2016, mezcla ciencia ficción y nostalgia ochentera."],
    ["¿Qué película ostenta el récord de recaudación mundial?", "Avatar", "Avengers: Endgame", "Titanic", "Star Wars: El despertar de la Fuerza", 2, "'Avatar' (2009) supera los 2.900 millones de dólares."],
    ["¿Quién dirigió la trilogía de 'El Señor de los Anillos'?", "Peter Jackson", "Guillermo del Toro", "George Lucas", "Ridley Scott", 2, "La trilogía se rodó simultáneamente en Nueva Zelanda."],
    ["¿Qué álbum de The Beatles muestra a la banda cruzando un paso de cebra?", "Abbey Road", "Revolver", "Sgt. Pepper's", "The White Album", 2, "Su portada de 1969 es una de las más imitadas de la historia."],
  ],
  [
    ["'Bohemian Rhapsody' es una canción de The Beatles.", false, 0, "Es de Queen, publicada en 1975."],
    ["'El Padrino' fue dirigida por Francis Ford Coppola.", true, 1, "Estrenada en 1972, ganó 3 premios Óscar."],
    ["'Toy Story' fue la primera película completamente animada por ordenador.", true, 2, "Pixar la estrenó en 1995."],
    ["Los premios Óscar se entregan cada dos años.", false, 0, "Se entregan anualmente desde 1929."],
    ["'Titanic' ganó 11 premios Óscar.", true, 1, "Empató el récord con 'Ben-Hur' y con 'El retorno del Rey'."],
  ],
  [
    [
      null,
      "Who directed 'Titanic' (1997)?|James Cameron|Steven Spielberg|Christopher Nolan|Ridley Scott||Cameron also directed 'Avatar' and 'Terminator'.",
      "Which film won the Best Picture Oscar in 2020 as the first non-English-language winner?|Parasite|Roma|1917|Joker||South Korea's 'Parasite' made Oscar history.",
      "What is the name of the wizard protagonist of J. K. Rowling's saga?|Harry Potter|Ron Weasley|Albus Dumbledore|Frodo Baggins||The saga began with 'The Philosopher's Stone' (2001 in film).",
      "Which British band sang 'Bohemian Rhapsody'?|Queen|The Beatles|The Rolling Stones|Pink Floyd||Freddie Mercury and Queen released it in 1975.",
      "Which Disney film features a princess named Elsa?|Frozen|Tangled|Moana|Brave||Elsa, the snow queen, stars in 'Frozen' (2013).",
      "Which actor plays Iron Man in the Marvel Universe?|Robert Downey Jr.|Chris Evans|Chris Hemsworth|Mark Ruffalo||He debuted as Tony Stark in the 2008 film.",
      "How many films make up the original 'Star Wars' trilogy?|3|2|4|6||Episodes IV, V and VI, released between 1977 and 1983.",
      "Which composer wrote the music for 'Star Wars', 'Indiana Jones' and 'Harry Potter'?|John Williams|Hans Zimmer|Ennio Morricone|Danny Elfman||Williams has won 5 Oscars and more than 25 Grammys.",
      "Which Netflix series follows a group of kids in Hawkins, Indiana?|Stranger Things|Dark|The Umbrella Academy|Riverdale||Released in 2016, it blends sci-fi and eighties nostalgia.",
      "Which film holds the worldwide box-office record?|Avatar|Avengers: Endgame|Titanic|Star Wars: The Force Awakens||'Avatar' (2009) exceeds 2.9 billion dollars.",
      "Who directed 'The Lord of the Rings' trilogy?|Peter Jackson|Guillermo del Toro|George Lucas|Ridley Scott||The trilogy was shot simultaneously in New Zealand.",
      "Which Beatles album shows the band crossing a zebra crossing?|Abbey Road|Revolver|Sgt. Pepper's|The White Album||Its 1969 cover is one of the most imitated ever.",
    ],
    [
      null,
      "'Bohemian Rhapsody' is a song by The Beatles.||Bohemian Rhapsody|It is by Queen, released in 1975.",
      "'The Godfather' was directed by Francis Ford Coppola.||O Poderoso Chefão|Released in 1972, it won 3 Oscars.",
      "'Toy Story' was the first fully computer-animated feature film.||Toy Story|Pixar released it in 1995.",
      "The Oscars are awarded every two years.||Oscar|They have been awarded annually since 1929.",
      "'Titanic' won 11 Academy Awards.||Titanic|It tied the record with 'Ben-Hur' and with 'The Return of the King'.",
    ],
  ]
);

const TECNOLOGIA = bank(
  "tecnologia",
  ["programacion", "javascript", "python", "html", "css", "codigo", "ordenador", "computadora", "internet", "tecnologia", "software", "ia", "videojuegos", "minecraft", "web", "react", "app"],
  [
    ["¿Qué lenguaje se usa para dar estilo a las páginas web?", "CSS", "HTML", "Python", "SQL", 0, "CSS (hojas de estilo en cascada) define colores, tipografías y diseño."],
    ["¿Qué significa HTML?", "HyperText Markup Language", "HighTech Modern Language", "Hyperlink Text Mode Language", "Home Tool Markup Language", 0, "Es el lenguaje de marcado que estructura el contenido web."],
    ["¿Qué empresa creó el iPhone?", "Apple", "Samsung", "Google", "Nokia", 0, "El primer iPhone se presentó en 2007."],
    ["¿Qué animal es la mascota de Linux?", "Un pingüino", "Un zorro", "Un elefante", "Un camaleón", 1, "Tux, el pingüino, es la mascota oficial del kernel Linux."],
    ["¿En qué lenguaje se escribe la lógica interactiva de una web en el navegador?", "JavaScript", "Java", "C++", "Go", 0, "JavaScript es el lenguaje nativo del navegador."],
    ["¿Qué símbolo se usa en Python para escribir comentarios de una línea?", "#", "//", "/* */", "--", 1, "En Python y muchos lenguajes de script, '#' abre un comentario."],
    ["¿Quién es considerado el creador de la World Wide Web?", "Tim Berners-Lee", "Bill Gates", "Steve Jobs", "Linus Torvalds", 1, "La propuso en el CERN en 1989."],
    ["¿Qué estructura de datos funciona con el principio 'el último en entrar es el primero en salir'?", "La pila (stack)", "La cola (queue)", "El array", "El grafo", 2, "La pila sigue el principio LIFO (Last In, First Out)."],
    ["¿En qué año se lanzó la primera versión de JavaScript?", "1995", "1989", "2001", "2010", 2, "Brendan Eich lo creó en Netscape en solo 10 días."],
    ["¿Qué hace el bucle 'for' en programación?", "Repite un bloque de código", "Define una función", "Declara una variable", "Importa una librería", 0, "Itera sobre una secuencia o hasta cumplir una condición."],
    ["¿Qué videojuego de bloques de 2011 se convirtió en el más vendido de la historia?", "Minecraft", "Roblox", "Terraria", "Fortnite", 1, "Creado por Markus 'Notch' Persson, supera los 300 millones de copias."],
    ["¿Qué complejidad tiene la búsqueda binaria sobre un array ordenado?", "O(log n)", "O(n)", "O(n log n)", "O(1)", 2, "Divide el espacio de búsqueda a la mitad en cada paso."],
  ],
  [
    ["HTML es un lenguaje de programación.", false, 1, "Es un lenguaje de marcado: estructura el contenido, no ejecuta lógica."],
    ["Python se publicó por primera vez en los años 50.", false, 0, "Guido van Rossum lo publicó en 1991."],
    ["En binario, el número 3 se escribe 11.", true, 2, "La secuencia binaria es 1, 10, 11, 100…"],
    ["El primer correo electrónico se envió en 1971.", true, 2, "Ray Tomlinson lo envió y popularizó el uso de la @."],
    ["Java y JavaScript son el mismo lenguaje.", false, 1, "Solo comparten el nombre por motivos de marketing de los 90."],
  ],
  [
    [
      null,
      "Which language is used to style web pages?|CSS|HTML|Python|SQL||CSS (cascading style sheets) defines colours, fonts and layout.",
      "What does HTML stand for?|HyperText Markup Language|HighTech Modern Language|Hyperlink Text Mode Language|Home Tool Markup Language||It is the markup language that structures web content.",
      "Which company created the iPhone?|Apple|Samsung|Google|Nokia||The first iPhone was presented in 2007.",
      "Which animal is the Linux mascot?|A penguin|A fox|An elephant|A chameleon||Tux the penguin is the official mascot of the Linux kernel.",
      "In which language is the interactive logic of a web page written in the browser?|JavaScript|Java|C++|Go||JavaScript is the native language of the browser.",
      "Which symbol is used in Python to write a single-line comment?|#|//|/* */|--||In Python and many scripting languages, '#' opens a comment.",
      "Who is considered the creator of the World Wide Web?|Tim Berners-Lee|Bill Gates|Steve Jobs|Linus Torvalds||He proposed it at CERN in 1989.",
      "Which data structure follows the 'last in, first out' principle?|The stack|The queue|The array|The graph||The stack follows the LIFO principle (Last In, First Out).",
      "In which year was the first version of JavaScript released?|1995|1989|2001|2010||Brendan Eich created it at Netscape in just 10 days.",
      "What does a 'for' loop do in programming?|Repeats a block of code|Defines a function|Declares a variable|Imports a library||It iterates over a sequence or until a condition is met.",
      "Which 2011 block-building video game became the best-selling in history?|Minecraft|Roblox|Terraria|Fortnite||Created by Markus 'Notch' Persson, it has passed 300 million copies.",
      "What is the complexity of binary search over a sorted array?|O(log n)|O(n)|O(n log n)|O(1)||It halves the search space at every step.",
    ],
    [
      null,
      "HTML is a programming language.||HTML|It is a markup language: it structures content, it does not run logic.",
      "Python was first released in the 1950s.||Python|Guido van Rossum released it in 1991.",
      "In binary, the number 3 is written 11.||Binário|The binary sequence is 1, 10, 11, 100…",
      "The first email was sent in 1971.||E-mail|Ray Tomlinson sent it and popularized the use of the @ symbol.",
      "Java and JavaScript are the same language.||Java|They only share the name due to 90s marketing.",
    ],
  ]
);

/* ------------------------------ traducciones ES ---------------------------- */

const TR_TITLES: Record<string, Record<Lang, string>> = {
  general: { es: "Cultura general", en: "General knowledge", pt: "Conhecimentos gerais" },
  historia: { es: "Historia", en: "History", pt: "História" },
  geografia: { es: "Geografía", en: "Geography", pt: "Geografia" },
  ciencia: { es: "Ciencia", en: "Science", pt: "Ciência" },
  deportes: { es: "Deportes", en: "Sports", pt: "Desportos" },
  cine: { es: "Cine y música", en: "Film & music", pt: "Cinema e música" },
  tecnologia: { es: "Programación y tecnología", en: "Programming & technology", pt: "Programação e tecnologia" },
};

const TR_MC: Record<string, (string | null)[]> = {
  geografia: [
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    "Qual é hoje a capital oficial do Cazaquistão?|Astaná|Almatý|Tashkent|Bishkek||A capital mudou de Almatý para Astaná (Nursultã entre 2019 e 2022).",
  ],
  ciencia: [
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    "Qual é o elemento químico mais abundante do universo?|Hidrógeno|Hélio|Oxigénio|Carbono||Cerca de 75% da matéria normal é hidrogênio.",
  ],
  deportes: [
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    "Em que ano a Espanha ganhou seu primeiro Mundial de futebol?|2010|2006|2014|1998||Foi na África do Sul 2010, com gol de Iniesta na prorrogação.",
  ],
  cine: [
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    "Qual álbum dos Beatles mostra a banda atravessando uma faixa de pedestres?|Abbey Road|Revolver|Sgt. Pepper's|The White Album||Sua capa de 1969 é uma das mais imitadas da história.",
  ],
};

/* --------------------------------- helpers --------------------------------- */

function parseMcRow(spec: string, fallback: BankRow): BankRow {
  const [pregunta, c, d1, d2, d3, , exp] = spec.split("|");
  return [pregunta ?? fallback[0], c ?? fallback[1], d1 ?? fallback[2], d2 ?? fallback[3], d3 ?? fallback[4], fallback[5], exp ?? fallback[6]];
}

function parseVfRow(spec: string, fallback: VfRow): VfRow {
  const [enun, , exp] = spec.split("|");
  return [enun ?? fallback[0], fallback[1], fallback[2], exp ?? fallback[3]];
}

export function getLocalizedBanks(lang: Lang): LocalBank[] {
  const defs: BankDef[] = [GENERAL, HISTORIA, GEOGRAFIA, CIENCIA, DEPORTES, CINE, TECNOLOGIA];
  return defs.map((d) => {
    const specMc: (string | null)[] = lang === "en" ? d.tr[0] : lang === "pt" ? TR_MC[d.id] ?? [] : [];
    const specVf: (string | null)[] = lang === "en" ? d.tr[1] : [];
    return {
      id: d.id,
      title: TR_TITLES[d.id][lang],
      keywords: d.keywords,
      rows: d.rows.map((r, i) => (specMc[i] ? parseMcRow(specMc[i] as string, r) : r)),
      vfRows: d.vfRows.map((r, i) => (specVf[i] ? parseVfRow(specVf[i] as string, r) : r)),
    };
  });
}
