export type Lang = "es" | "en" | "pt";

export interface LangMeta {
  code: Lang;
  label: string;
  native: string;
}

export const LANGS: LangMeta[] = [
  { code: "es", label: "Español", native: "ES" },
  { code: "en", label: "English", native: "EN" },
  { code: "pt", label: "Português", native: "PT" },
];

export interface Strings {
  badge: string;
  heroA: string;
  heroB: string;
  heroC: string;
  sub: string;
  topicLabel: string;
  topicPlaceholder: string;
  countLabel: string;
  countSuffix: string;
  difficultyLabel: string;
  diff: Record<"facil" | "medio" | "dificil", { label: string; desc: string; hint: string }>;
  generate: (n: number, d: string) => string;
  genNote: (n: number, d: string) => string;
  features: [string, string][];
  suggestions: string[];
  generating: string[];
  generatingTopic: string;
  cancel: string;
  quit: string;
  correct: string;
  incorrect: string;
  next: string;
  seeResults: string;
  keyHintMc: string;
  keyHintVf: string;
  typeMc: string;
  typeVf: string;
  typeVfShort: string;
  resultsTitle: (topic: string) => string;
  accuracy: string;
  hits: string;
  misses: string;
  time: string;
  level: string;
  msg90: string;
  msg70: string;
  msg40: string;
  msg0: string;
  localNote: (bank: string) => string;
  retry: string;
  newTopic: string;
  review: string;
  yourAnswer: string;
  correctAnswer: string;
  noAnswer: string;
  footer: string;
  themeToggleDark: string;
  themeToggleLight: string;
  langLabel: string;
  vfFallbackTrue: string;
  vfFallbackFalse: string;
  unfinishedTitle: string;
  unfinishedDesc: string;
  unfinishedFinish: string;
  unfinishedStay: string;
}

export const T: Record<Lang, Strings> = {
  es: {
    badge: "Generador de cuestionarios con IA",
    heroA: "Convierte cualquier tema en un",
    heroB: "cuestionario",
    heroC: "al instante.",
    sub: "Escribe el tema, ajusta el número de preguntas, elige la dificultad y deja que la inteligencia artificial haga el resto.",
    topicLabel: "Tema del cuestionario",
    topicPlaceholder: "Ej.: El Imperio Romano, fotografía, anatomía…",
    countLabel: "Nº de preguntas",
    countSuffix: "preguntas",
    difficultyLabel: "Dificultad",
    diff: {
      facil: { label: "Fácil", desc: "Conceptos básicos y datos muy conocidos.", hint: "preguntas sencillas: definiciones, datos muy conocidos y conceptos básicos que casi cualquier aficionado al tema conocería" },
      medio: { label: "Medio", desc: "Relaciones, detalles y datos menos evidentes.", hint: "preguntas de nivel intermedio: relaciones entre conceptos, causas y consecuencias, comparaciones y datos menos evidentes" },
      dificil: { label: "Difícil", desc: "Conocimiento especializado y distractores tramposos.", hint: "preguntas de nivel experto: datos especializados, fechas exactas, detalles poco conocidos y distractores muy plausibles" },
    },
    generate: () => "Generar cuestionario",
    genNote: (n, d) => `La IA creará ${n} ${n === 1 ? "pregunta" : "preguntas"} de opción múltiple y verdadero/falso en nivel ${d.toLowerCase()} — sin registro, gratis.`,
    features: [
      ["Dos formatos", "Opción múltiple y verdadero/falso al azar"],
      ["Explicaciones", "Aprende el porqué de cada acierto"],
      ["Tres idiomas", "Español, inglés y portugués"],
    ],
    suggestions: ["Historia del arte", "JavaScript", "El espacio exterior", "Fútbol", "Biología celular", "Cine de los 90", "Antigua Roma", "Mitología griega"],
    generating: ["Analizando el tema…", "Consultando a la IA…", "Redactando preguntas…", "Afinando la dificultad…", "Puliendo los distractores…", "Último repaso…"],
    generatingTopic: "Generando cuestionario",
    cancel: "Cancelar",
    quit: "Salir del cuestionario",
    correct: "¡Correcto!",
    incorrect: "Incorrecto",
    next: "Siguiente pregunta",
    seeResults: "Ver resultados",
    keyHintMc: "Pulsa 1–4 para responder y Enter para continuar",
    keyHintVf: "Pulsa V o F para responder y Enter para continuar",
    typeMc: "Opción múltiple",
    typeVf: "Verdadero o falso",
    typeVfShort: "Verdadero/Falso",
    resultsTitle: (topic) => `Resultados · ${topic}`,
    accuracy: "de aciertos",
    hits: "Aciertos",
    misses: "Fallos",
    time: "Tiempo",
    level: "Nivel",
    msg90: "¡Nivel experto, increíble!",
    msg70: "¡Muy buen trabajo!",
    msg40: "Buen intento, vas por buen camino.",
    msg0: "Toca repasar un poco más.",
    localNote: (bank) => `Generado desde el banco local «${bank}» (IA sin conexión)`,
    retry: "Generar otro",
    newTopic: "Cambiar tema",
    review: "Repaso de respuestas",
    yourAnswer: "Tu respuesta",
    correctAnswer: "Correcta",
    noAnswer: "Sin responder",
    footer: "QuizMind · Cuestionarios generados con inteligencia artificial",
    themeToggleDark: "Cambiar a modo oscuro",
    themeToggleLight: "Cambiar a modo claro",
    langLabel: "Idioma",
    vfFallbackTrue: "El enunciado es verdadero.",
    vfFallbackFalse: "El enunciado es falso.",
    unfinishedTitle: "¿Terminar cuestionario?",
    unfinishedDesc: "Aún tienes preguntas pendientes. Puedes terminar ahora o seguir respondiendo.",
    unfinishedFinish: "Terminar ahora",
    unfinishedStay: "Seguir respondiendo",
  },

  en: {
    badge: "AI quiz generator",
    heroA: "Turn any topic into a",
    heroB: "quiz",
    heroC: "instantly.",
    sub: "Type a topic, set the number of questions, pick a difficulty and let artificial intelligence do the rest.",
    topicLabel: "Quiz topic",
    topicPlaceholder: "E.g.: The Roman Empire, photography, anatomy…",
    countLabel: "Number of questions",
    countSuffix: "questions",
    difficultyLabel: "Difficulty",
    diff: {
      facil: { label: "Easy", desc: "Basic concepts and well-known facts.", hint: "easy questions: definitions, well-known facts and basic concepts that almost any fan of the topic would know" },
      medio: { label: "Medium", desc: "Connections, details and less obvious facts.", hint: "intermediate questions: relationships between concepts, causes and consequences, comparisons and less obvious details" },
      dificil: { label: "Hard", desc: "Specialist knowledge and tricky distractors.", hint: "expert-level questions: specialized facts, exact dates, little-known details and very plausible distractors" },
    },
    generate: () => "Generate quiz",
    genNote: (n, d) => `The AI will create ${n} multiple-choice and true/false ${n === 1 ? "question" : "questions"} at ${d.toLowerCase()} level — free, no sign-up.`,
    features: [
      ["Two formats", "Multiple choice and true/false at random"],
      ["Explanations", "Learn the why behind every answer"],
      ["Three languages", "Spanish, English and Portuguese"],
    ],
    suggestions: ["Art history", "JavaScript", "Outer space", "Football", "Cell biology", "90s cinema", "Ancient Rome", "Greek mythology"],
    generating: ["Analyzing the topic…", "Asking the AI…", "Writing questions…", "Tuning the difficulty…", "Polishing the distractors…", "Final review…"],
    generatingTopic: "Generating quiz",
    cancel: "Cancel",
    quit: "Exit quiz",
    correct: "Correct!",
    incorrect: "Incorrect",
    next: "Next question",
    seeResults: "See results",
    keyHintMc: "Press 1–4 to answer and Enter to continue",
    keyHintVf: "Press T or F to answer and Enter to continue",
    typeMc: "Multiple choice",
    typeVf: "True or false",
    typeVfShort: "True/False",
    resultsTitle: (topic) => `Results · ${topic}`,
    accuracy: "correct",
    hits: "Correct",
    misses: "Wrong",
    time: "Time",
    level: "Level",
    msg90: "Expert level, amazing!",
    msg70: "Great job!",
    msg40: "Good try, you're on the right track.",
    msg0: "Time to review a bit more.",
    localNote: (bank) => `Generated from the local "${bank}" set (AI offline)`,
    retry: "Generate another",
    newTopic: "Change topic",
    review: "Answer review",
    yourAnswer: "Your answer",
    correctAnswer: "Correct",
    noAnswer: "Not answered",
    footer: "QuizMind · Quizzes generated with artificial intelligence",
    themeToggleDark: "Switch to dark mode",
    themeToggleLight: "Switch to light mode",
    langLabel: "Language",
    vfFallbackTrue: "The statement is true.",
    vfFallbackFalse: "The statement is false.",
    unfinishedTitle: "Finish the quiz?",
    unfinishedDesc: "You still have unanswered questions. Finish now or keep answering.",
    unfinishedFinish: "Finish now",
    unfinishedStay: "Keep answering",
  },

  pt: {
    badge: "Gerador de questionários com IA",
    heroA: "Transforme qualquer tema num",
    heroB: "questionário",
    heroC: "instantaneamente.",
    sub: "Digite o tema, ajuste o número de perguntas, escolha a dificuldade e deixe a inteligência artificial fazer o resto.",
    topicLabel: "Tema do questionário",
    topicPlaceholder: "Ex.: O Império Romano, fotografia, anatomia…",
    countLabel: "Nº de perguntas",
    countSuffix: "perguntas",
    difficultyLabel: "Dificuldade",
    diff: {
      facil: { label: "Fácil", desc: "Conceitos básicos e fatos bem conhecidos.", hint: "perguntas simples: definições, fatos muito conhecidos e conceitos básicos que quase qualquer fã do tema conheceria" },
      medio: { label: "Médio", desc: "Relações, detalhes e fatos menos evidentes.", hint: "perguntas de nível intermediário: relações entre conceitos, causas e consequências, comparações e detalhes menos evidentes" },
      dificil: { label: "Difícil", desc: "Conhecimento especializado e distratores traiçoeiros.", hint: "perguntas de nível especialista: dados especializados, datas exatas, detalhes pouco conhecidos e distratores muito plausíveis" },
    },
    generate: () => "Gerar questionário",
    genNote: (n, d) => `A IA vai criar ${n} ${n === 1 ? "pergunta" : "perguntas"} de múltipla escolha e verdadeiro/falso no nível ${d.toLowerCase()} — grátis, sem cadastro.`,
    features: [
      ["Dois formatos", "Múltipla escolha e verdadeiro/falso ao acaso"],
      ["Explicações", "Aprenda o porquê de cada acerto"],
      ["Três idiomas", "Espanhol, inglês e português"],
    ],
    suggestions: ["História da arte", "JavaScript", "O espaço sideral", "Futebol", "Biologia celular", "Cinema dos anos 90", "Roma Antiga", "Mitologia grega"],
    generating: ["Analisando o tema…", "Consultando a IA…", "Escrevendo perguntas…", "Ajustando a dificuldade…", "Aperfeiçoando os distratores…", "Revisão final…"],
    generatingTopic: "Gerando questionário",
    cancel: "Cancelar",
    quit: "Sair do questionário",
    correct: "Correto!",
    incorrect: "Incorreto",
    next: "Próxima pergunta",
    seeResults: "Ver resultados",
    keyHintMc: "Pressione 1–4 para responder e Enter para continuar",
    keyHintVf: "Pressione V ou F para responder e Enter para continuar",
    typeMc: "Múltipla escolha",
    typeVf: "Verdadeiro ou falso",
    typeVfShort: "Verdadeiro/Falso",
    resultsTitle: (topic) => `Resultados · ${topic}`,
    accuracy: "de acertos",
    hits: "Acertos",
    misses: "Erros",
    time: "Tempo",
    level: "Nível",
    msg90: "Nível especialista: incrível!",
    msg70: "Ótimo trabalho!",
    msg40: "Boa tentativa, você está no caminho certo.",
    msg0: "Hora de revisar um pouco mais.",
    localNote: (bank) => `Gerado do banco local «${bank}» (IA sem conexão)`,
    retry: "Gerar outro",
    newTopic: "Mudar tema",
    review: "Revisão das respostas",
    yourAnswer: "Sua resposta",
    correctAnswer: "Correta",
    noAnswer: "Sem resposta",
    footer: "QuizMind · Questionários gerados com inteligência artificial",
    themeToggleDark: "Mudar para o modo escuro",
    themeToggleLight: "Mudar para o modo claro",
    langLabel: "Idioma",
    vfFallbackTrue: "A afirmação é verdadeira.",
    vfFallbackFalse: "A afirmação é falsa.",
    unfinishedTitle: "Terminar o questionário?",
    unfinishedDesc: "Você ainda tem perguntas pendentes. Termine agora ou continue respondendo.",
    unfinishedFinish: "Terminar agora",
    unfinishedStay: "Continuar respondendo",
  },
};

export const VF_LABELS: Record<Lang, [string, string]> = {
  es: ["Verdadero", "Falso"],
  en: ["True", "False"],
  pt: ["Verdadeiro", "Falso"],
};
